# Nine Depths and Their Defenders

| Floor | Setting | Boss | 3 unique enemies | Boss attack identity |
|---|---|---|---|---|
| 1 | Keeper’s Quarters | The Bellwright | Lamp Moth (moth), Dust Rat (chaser), Oil Drip (splitter) | bell |
| 2 | Flooded Maintenance | The Bilge Mother | Barnacle Skitter (chaser), Valve Leech (leech), Pressure Wraith (sniper) | pressure |
| 3 | Salt Chapel | Saint of Brine | Chalk Acolyte (sniper), Pale Mourner (charger), Reliquary Crab (armored) | salvo |
| 4 | Molded Bunks | Mycelium Admiral | Spore Husk (splitter), Fungal Blink (teleporter), Bedframe Stalker (charger) | spore |
| 5 | Brass Inferno | The Furnace Warden | Cinder Imp (rusher), Coal Golem (armored), Chain Spark (orbiter) | charge |
| 6 | Drowned Ossuary | The Sunken Choir | Skull Lantern (orbiter), Drowned Gunner (sniper), Bone Eel (leech) | choir |
| 7 | The False Lens | The Glass Matriarch | Lens Phantom (teleporter), Mirror Hound (charger), Prism Eye (sniper) | mirror |
| 8 | The Black Tide | The Abyssal Leviathan | Ink Revenant (splitter), Deepwake Hunter (rusher), Void Angler (leech) | vortex |
| 9 | The Buried Sun | The First Keeper | Hellglass Sentinel (armored), Molten Seraph (orbiter), Ash Chronist (teleporter) | eclipse |

## Boss room rules
Every fourth chamber has an actual boss enemy with unique radial or fan patterns, damage, HP and boss loot. Each boss has its own attack pattern identifier in `full-catalog.json`: bell, pressure, salvo, spore, charge, choir, mirror, vortex and eclipse. Floors grow progressively darker and more warped through nine themed art-derived environmental layers.

## Encounter loops
Randomized enemy placements with collision checks; fights yield XP and coins. Chest/shop appearance is seeded per room. Hardness scales with floor. Boss death unlocks next floor and a new weapon.
