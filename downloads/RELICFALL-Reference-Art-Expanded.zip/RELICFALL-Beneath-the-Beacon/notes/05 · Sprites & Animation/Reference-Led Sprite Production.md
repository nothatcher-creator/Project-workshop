# Reference-led sprite production (No Templates)

## Sources
1. Keeper portrait: `references/keeper-reference.webp` (character silhouette, red scarf, white suspenders, brass details).
2. Lighthouse boss: `references/leviathan-boss.webp` (corrupted tentacles, lantern body, rust and slime).
3. Environment: `references/gearworks-reference.webp`, `references/descent-reference.webp`, `references/abyss-reference.webp`.

## Practical art workflow
1. Crop the appropriate approved source image into a mood/reference board for a *specific character or room*.
2. Generate a single finished transparent top-down key pose for each enemy/boss/weapon, consistent with the keeper/leviathan style.
3. Review top-down readability at 48–128px and rescale to fixed game sizes.
4. Animate that approved pose into idle, move, attack, hit and death actions, maintaining one uniform camera and pivot.
5. Assemble sprites into any atlas layout needed by the engine (machine-readable JSON frame rectangles); **do not output blank grid layouts or gray placeholder sprites**.
6. Preserve original master art and document usage rights.

## Existing state
The game uses derived images for playable backdrop layers, menu, character and leviathan. Other enemies currently render as distinct geometric silhouettes with VFX until their proper referenced artwork exists. Never label unfinished silhouettes as final art.
