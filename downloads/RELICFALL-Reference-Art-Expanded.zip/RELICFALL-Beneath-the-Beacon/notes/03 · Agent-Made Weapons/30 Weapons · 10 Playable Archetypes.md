# Agent-Made Weapons — Working Game Content

All thirty designs are in `data/full-catalog.json`, and each weapon type executes different logic (bows shoot piercing arrows, staffs fire arcane projectiles, summoners spawn companions, blades slash, beams hit in line, crossbows fire burst bolts, lanterns radiate light, throwers create explosions, etc.).

| Name | Family | Rarity | Damage | Rate (s) | Range | Attack behaviour |
|---|---|---|---:|---:|---:|---|
| The Wickpiercer | harpoon | common | 11.0 | 0.69 | 270 | flares |
| Tidebreaker Harpoon | harpoon | rare | 16.0 | 0.62 | 270 | flares |
| The Gilded Nail | harpoon | legendary | 21.0 | 0.56 | 270 | flares |
| Mournwood Bow | bow | common | 11.7 | 0.87 | 400 | pierce |
| Saltwind Recurve | bow | rare | 16.7 | 0.8 | 400 | pierce |
| The Cinderbranch | bow | legendary | 21.7 | 0.74 | 400 | pierce |
| Choir Staff | staff | common | 12.4 | 0.94 | 330 | chain |
| Lantern Rod | staff | rare | 17.4 | 0.88 | 330 | chain |
| Blacktide Scepter | staff | legendary | 22.4 | 0.81 | 330 | chain |
| Barnacle Tome | summoner | common | 8.5 | 1.48 | 340 | minion |
| Choir of Lanterns | summoner | rare | 11.8 | 1.42 | 340 | minion |
| The Husk Reliquary | summoner | legendary | 15.0 | 1.35 | 340 | minion |
| Gale Cutlass | blade | common | 13.8 | 0.41 | 85 | cleave |
| Keeper’s Oath | blade | rare | 18.8 | 0.34 | 85 | cleave |
| Anchor of Souls | blade | legendary | 23.8 | 0.28 | 85 | cleave |
| Pier Glass | crossbow | common | 14.5 | 0.6 | 380 | burst |
| Rustlock Repeater | crossbow | rare | 19.5 | 0.53 | 380 | burst |
| Furnace Bolt | crossbow | legendary | 24.5 | 0.47 | 380 | burst |
| Oculus of Foam | orb | common | 15.2 | 0.91 | 280 | orbit |
| The False Moon | orb | rare | 20.2 | 0.84 | 280 | orbit |
| Undertow Eye | orb | legendary | 25.2 | 0.78 | 280 | orbit |
| Pilgrim Lens | beam | common | 10.3 | 0.23 | 315 | sweep |
| Sunspindle | beam | rare | 13.6 | 0.23 | 315 | sweep |
| The White Seam | beam | legendary | 16.8 | 0.23 | 315 | sweep |
| Brine Flask | thrower | common | 16.6 | 1.17 | 225 | splash |
| Ash Bombard | thrower | rare | 21.6 | 1.1 | 225 | splash |
| The Black Oil | thrower | legendary | 26.6 | 1.04 | 225 | splash |
| Storm Lantern | lantern | common | 11.2 | 0.75 | 205 | aura |
| Dirge Beacon | lantern | rare | 14.5 | 0.69 | 205 | aura |
| The First Flame | lantern | legendary | 17.7 | 0.62 | 205 | aura |

## AI art handoff
Give the agent **specific** user reference images, weapon catalog row, 3/4 top-down orientation, transparent PNG output, exact pixel dimensions (suggested 256×256 master), one intact icon plus separate projectile/impact visual. Never ask for an empty sprite grid. Additional animation frames should be generated from the approved key pose to keep continuity.

## Showcase
`prototype/community-showcase.json` is a curated read-only public shelf. Players can create custom designs and share JSON codes locally; any new server-hosted submission needs authentication, approval and moderation before becoming publicly visible.
