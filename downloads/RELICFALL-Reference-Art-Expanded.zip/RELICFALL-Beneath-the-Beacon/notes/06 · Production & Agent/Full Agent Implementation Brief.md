# Agent Build Instructions

**Objective:** Deliver a polished top-down Project0-compatible roguelike under a lighthouse. Be reference-image-driven, not template-driven.

## Ordered tasks
1. Inspect all five `references/*.webp` assets, the nine reference-derived environment images, and `data/reference-art-asset-manifest.json`.
2. Preserve working runtime; avoid rewriting already-complete progression, menus, 200 stat items, 30 achievements, 30 weapon designs and 9 floor boss patterns.
3. Replace prototype geometric enemies with finished referenced top-down art for each of the 27 named floor enemies; create true boss art for all nine bosses.
4. Generate proper animations starting from a finished pose (never blank atlas templates). Integrate independent effects, pivots, dodge afterimages and hit feedback.
5. Add floor-specific sound, boss telegraphs, tutorials, secrets and shop visuals; verify mobile portrait input.
6. Confirm Project0 embedding/hosting and custom avatar permissions with actual SDK docs, never invent integration capabilities.
7. Run browser/mobile smoke tests on real devices before claiming production quality; list remaining shortcomings honestly.

## Complete mechanics delivered
Mobile auto-fire default on, toggle, manual fire, dodge, 9 bosses, 3 specific enemies per floor, chests, merchant shop, 200 item modifiers, 30 persistent achievements, tutorial, menu, individual weapon behaviours, secret vault encounters, reference-based layer backgrounds, local weapon share-code gallery, community featured shelf with curated JSON.

## Known limits
The community shelf is not a writeable multiplayer backend. Audio has not been sourced; enemy/boss full animated sprite sets still need reference-derived generation; balancing of 200 stat effects is an iterative pass.
