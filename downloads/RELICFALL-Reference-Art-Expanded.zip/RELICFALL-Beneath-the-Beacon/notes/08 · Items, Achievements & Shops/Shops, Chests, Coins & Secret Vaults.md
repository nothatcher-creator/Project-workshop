# Interactive Economy and Exploration

**Coins:** Dropped by defeated enemies and boss kills; coins magnetize to the player and are spent in shops.

**Treasure chests:** Interact when nearby to choose a relic; bosses can offer a weapon unlock.

**Shops:** Interact with merchant to purchase relics or weapon variants; prices scale by floor. The UI tells you why a purchase fails.

**Secret rooms:** Look for an unusual crack on west walls, approach and use INTERACT. A distinct vault chamber spawns enemies and a hidden chest, with its own exit back to the main chamber. Secret discovery achievements persist.

**Additional ideas:** Cursed bargain (item + price), treasure mimic, floor-specific merchant portrait, rare shop restocks, boss shrine. These are future extensions rather than claimed implemented features.
