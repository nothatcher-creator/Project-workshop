# All 30 Achievements

Achievements persist to browser storage. Unlocks are triggered by tracked run actions.

| # | Achievement | Condition | Progress key | Goal |
|---:|---|---|---|---:|
| 1 | First Flame | Start your first watch | runs | 1 |
| 2 | Moth Collector | Kill 25 enemies | kills | 25 |
| 3 | Keeper of the Deep | Kill 150 enemies | kills | 150 |
| 4 | Warden of Ash | Kill 500 enemies | kills | 500 |
| 5 | Hand on the Wheel | Dodge 10 times | dodges | 10 |
| 6 | Perfect Escape | Dodge 75 times | dodges | 75 |
| 7 | Oil Tycoon | Collect 100 coins | coins | 100 |
| 8 | Treasure Diver | Open 10 chests | chests | 10 |
| 9 | Salt Hoarder | Open 35 chests | chests | 35 |
| 10 | Deal with the Devil | Buy 5 shop items | purchases | 5 |
| 11 | Whale Oil Dealer | Buy 25 shop items | purchases | 25 |
| 12 | Knock Twice | Discover a secret room | secrets | 1 |
| 13 | Architect of Lies | Find 9 secret rooms | secrets | 9 |
| 14 | Alchemist | Collect 20 items | items | 20 |
| 15 | Relic Hunter | Collect 100 items | items | 100 |
| 16 | Arsenal | Unlock 5 weapons | weapons | 5 |
| 17 | Armory Keeper | Unlock 20 weapons | weapons | 20 |
| 18 | The Bell Tolls | Defeat the first boss | bosses | 1 |
| 19 | The Bell Falls | Defeat 4 bosses in a run | bosses | 4 |
| 20 | Hellbreaker | Defeat the final boss | wins | 1 |
| 21 | Night Watch | Complete 5 runs | runs | 5 |
| 22 | Weathered | Complete 25 runs | runs | 25 |
| 23 | First Lesson | Finish the tutorial | tutorial | 1 |
| 24 | Through the Water | Reach depth 2 | depth | 2 |
| 25 | The Lens Watches | Reach depth 7 | depth | 7 |
| 26 | Shadows Below | Reach depth 9 | depth | 9 |
| 27 | Arcane Collector | Use a magic staff | staffUses | 1 |
| 28 | Call the Drowned | Summon 20 allies | summons | 20 |
| 29 | Sharpshooter | Land 200 hits | hits | 200 |
| 30 | Community Curator | Save a custom weapon to showcase | showcases | 1 |