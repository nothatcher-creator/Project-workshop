# Complete Item Catalog — 200 Unique Named Relics

All 200 item IDs and effects are shipped in JSON, not just promised. Loot appears in level choices, shops, treasure chests and secret vaults. Effects are applied immediately to actual player stats. All 20 effect keys are mapped in `prototype/game.js`: power, health, speed, rate, range, fortune, armor, crit, chain, splash, burn, slow, coins, regen, dodge, projectiles, bossDamage, lifesteal, secrets and xp.

| # | Item | Rarity | Category | Gameplay effect | Value |
|---:|---|---|---|---|---:|
| 1 | Copper Power | common | relic | power | 0.025 |
| 2 | Copper Heart | common | equipment | health | 7 |
| 3 | Copper Sea Legs | common | charm | speed | 0.025 |
| 4 | Copper Quick Wick | common | consumable | rate | 0.025 |
| 5 | Copper Far Light | common | relic | range | 0.025 |
| 6 | Copper Scavenger | common | equipment | fortune | 0.025 |
| 7 | Copper Salt Armor | common | charm | armor | 0.025 |
| 8 | Copper Solemn Focus | common | consumable | crit | 0.025 |
| 9 | Copper Bell Echo | common | relic | chain | 0.025 |
| 10 | Copper Shock Shell | common | equipment | splash | 0.025 |
| 11 | Copper Lamp Oil | common | charm | burn | 0.025 |
| 12 | Copper Frost Brine | common | consumable | slow | 0.025 |
| 13 | Copper Deep Pockets | common | relic | coins | 0.025 |
| 14 | Copper Diver’s Lung | common | equipment | regen | 0.09 |
| 15 | Copper Anchorstep | common | charm | dodge | 0.025 |
| 16 | Copper Lighthouse Prism | common | consumable | projectiles | 0.1 |
| 17 | Copper Exorcist | common | relic | bossDamage | 0.025 |
| 18 | Copper Tide Drain | common | equipment | lifesteal | 0.025 |
| 19 | Copper Cartographer | common | charm | secrets | 16 |
| 20 | Copper Shrine Prayer | common | consumable | xp | 0.025 |
| 21 | Brine-Stained Power | common | relic | power | 0.036 |
| 22 | Brine-Stained Heart | common | equipment | health | 12 |
| 23 | Brine-Stained Sea Legs | common | charm | speed | 0.036 |
| 24 | Brine-Stained Quick Wick | common | consumable | rate | 0.036 |
| 25 | Brine-Stained Far Light | common | relic | range | 0.036 |
| 26 | Brine-Stained Scavenger | common | equipment | fortune | 0.036 |
| 27 | Brine-Stained Salt Armor | common | charm | armor | 0.036 |
| 28 | Brine-Stained Solemn Focus | common | consumable | crit | 0.036 |
| 29 | Brine-Stained Bell Echo | common | relic | chain | 0.036 |
| 30 | Brine-Stained Shock Shell | common | equipment | splash | 0.036 |
| 31 | Brine-Stained Lamp Oil | common | charm | burn | 0.036 |
| 32 | Brine-Stained Frost Brine | common | consumable | slow | 0.036 |
| 33 | Brine-Stained Deep Pockets | common | relic | coins | 0.036 |
| 34 | Brine-Stained Diver’s Lung | common | equipment | regen | 0.14 |
| 35 | Brine-Stained Anchorstep | common | charm | dodge | 0.036 |
| 36 | Brine-Stained Lighthouse Prism | common | consumable | projectiles | 0.14 |
| 37 | Brine-Stained Exorcist | common | relic | bossDamage | 0.036 |
| 38 | Brine-Stained Tide Drain | common | equipment | lifesteal | 0.036 |
| 39 | Brine-Stained Cartographer | common | charm | secrets | 23 |
| 40 | Brine-Stained Shrine Prayer | common | consumable | xp | 0.036 |
| 41 | Keeper’s Power | uncommon | relic | power | 0.047 |
| 42 | Keeper’s Heart | uncommon | equipment | health | 17 |
| 43 | Keeper’s Sea Legs | uncommon | charm | speed | 0.047 |
| 44 | Keeper’s Quick Wick | uncommon | consumable | rate | 0.047 |
| 45 | Keeper’s Far Light | uncommon | relic | range | 0.047 |
| 46 | Keeper’s Scavenger | uncommon | equipment | fortune | 0.047 |
| 47 | Keeper’s Salt Armor | uncommon | charm | armor | 0.047 |
| 48 | Keeper’s Solemn Focus | uncommon | consumable | crit | 0.047 |
| 49 | Keeper’s Bell Echo | uncommon | relic | chain | 0.047 |
| 50 | Keeper’s Shock Shell | uncommon | equipment | splash | 0.047 |
| 51 | Keeper’s Lamp Oil | uncommon | charm | burn | 0.047 |
| 52 | Keeper’s Frost Brine | uncommon | consumable | slow | 0.047 |
| 53 | Keeper’s Deep Pockets | uncommon | relic | coins | 0.047 |
| 54 | Keeper’s Diver’s Lung | uncommon | equipment | regen | 0.19 |
| 55 | Keeper’s Anchorstep | uncommon | charm | dodge | 0.047 |
| 56 | Keeper’s Lighthouse Prism | uncommon | consumable | projectiles | 0.18 |
| 57 | Keeper’s Exorcist | uncommon | relic | bossDamage | 0.047 |
| 58 | Keeper’s Tide Drain | uncommon | equipment | lifesteal | 0.047 |
| 59 | Keeper’s Cartographer | uncommon | charm | secrets | 30 |
| 60 | Keeper’s Shrine Prayer | uncommon | consumable | xp | 0.047 |
| 61 | Floodborn Power | uncommon | relic | power | 0.058 |
| 62 | Floodborn Heart | uncommon | equipment | health | 22 |
| 63 | Floodborn Sea Legs | uncommon | charm | speed | 0.058 |
| 64 | Floodborn Quick Wick | uncommon | consumable | rate | 0.058 |
| 65 | Floodborn Far Light | uncommon | relic | range | 0.058 |
| 66 | Floodborn Scavenger | uncommon | equipment | fortune | 0.058 |
| 67 | Floodborn Salt Armor | uncommon | charm | armor | 0.058 |
| 68 | Floodborn Solemn Focus | uncommon | consumable | crit | 0.058 |
| 69 | Floodborn Bell Echo | uncommon | relic | chain | 0.058 |
| 70 | Floodborn Shock Shell | uncommon | equipment | splash | 0.058 |
| 71 | Floodborn Lamp Oil | uncommon | charm | burn | 0.058 |
| 72 | Floodborn Frost Brine | uncommon | consumable | slow | 0.058 |
| 73 | Floodborn Deep Pockets | uncommon | relic | coins | 0.058 |
| 74 | Floodborn Diver’s Lung | uncommon | equipment | regen | 0.24 |
| 75 | Floodborn Anchorstep | uncommon | charm | dodge | 0.058 |
| 76 | Floodborn Lighthouse Prism | uncommon | consumable | projectiles | 0.22 |
| 77 | Floodborn Exorcist | uncommon | relic | bossDamage | 0.058 |
| 78 | Floodborn Tide Drain | uncommon | equipment | lifesteal | 0.058 |
| 79 | Floodborn Cartographer | uncommon | charm | secrets | 37 |
| 80 | Floodborn Shrine Prayer | uncommon | consumable | xp | 0.058 |
| 81 | Saltbound Power | rare | relic | power | 0.069 |
| 82 | Saltbound Heart | rare | equipment | health | 27 |
| 83 | Saltbound Sea Legs | rare | charm | speed | 0.069 |
| 84 | Saltbound Quick Wick | rare | consumable | rate | 0.069 |
| 85 | Saltbound Far Light | rare | relic | range | 0.069 |
| 86 | Saltbound Scavenger | rare | equipment | fortune | 0.069 |
| 87 | Saltbound Salt Armor | rare | charm | armor | 0.069 |
| 88 | Saltbound Solemn Focus | rare | consumable | crit | 0.069 |
| 89 | Saltbound Bell Echo | rare | relic | chain | 0.069 |
| 90 | Saltbound Shock Shell | rare | equipment | splash | 0.069 |
| 91 | Saltbound Lamp Oil | rare | charm | burn | 0.069 |
| 92 | Saltbound Frost Brine | rare | consumable | slow | 0.069 |
| 93 | Saltbound Deep Pockets | rare | relic | coins | 0.069 |
| 94 | Saltbound Diver’s Lung | rare | equipment | regen | 0.29 |
| 95 | Saltbound Anchorstep | rare | charm | dodge | 0.069 |
| 96 | Saltbound Lighthouse Prism | rare | consumable | projectiles | 0.26 |
| 97 | Saltbound Exorcist | rare | relic | bossDamage | 0.069 |
| 98 | Saltbound Tide Drain | rare | equipment | lifesteal | 0.069 |
| 99 | Saltbound Cartographer | rare | charm | secrets | 44 |
| 100 | Saltbound Shrine Prayer | rare | consumable | xp | 0.069 |
| 101 | Fungal Power | rare | relic | power | 0.08 |
| 102 | Fungal Heart | rare | equipment | health | 32 |
| 103 | Fungal Sea Legs | rare | charm | speed | 0.08 |
| 104 | Fungal Quick Wick | rare | consumable | rate | 0.08 |
| 105 | Fungal Far Light | rare | relic | range | 0.08 |
| 106 | Fungal Scavenger | rare | equipment | fortune | 0.08 |
| 107 | Fungal Salt Armor | rare | charm | armor | 0.08 |
| 108 | Fungal Solemn Focus | rare | consumable | crit | 0.08 |
| 109 | Fungal Bell Echo | rare | relic | chain | 0.08 |
| 110 | Fungal Shock Shell | rare | equipment | splash | 0.08 |
| 111 | Fungal Lamp Oil | rare | charm | burn | 0.08 |
| 112 | Fungal Frost Brine | rare | consumable | slow | 0.08 |
| 113 | Fungal Deep Pockets | rare | relic | coins | 0.08 |
| 114 | Fungal Diver’s Lung | rare | equipment | regen | 0.34 |
| 115 | Fungal Anchorstep | rare | charm | dodge | 0.08 |
| 116 | Fungal Lighthouse Prism | rare | consumable | projectiles | 0.3 |
| 117 | Fungal Exorcist | rare | relic | bossDamage | 0.08 |
| 118 | Fungal Tide Drain | rare | equipment | lifesteal | 0.08 |
| 119 | Fungal Cartographer | rare | charm | secrets | 51 |
| 120 | Fungal Shrine Prayer | rare | consumable | xp | 0.08 |
| 121 | Cinder Power | epic | relic | power | 0.091 |
| 122 | Cinder Heart | epic | equipment | health | 37 |
| 123 | Cinder Sea Legs | epic | charm | speed | 0.091 |
| 124 | Cinder Quick Wick | epic | consumable | rate | 0.091 |
| 125 | Cinder Far Light | epic | relic | range | 0.091 |
| 126 | Cinder Scavenger | epic | equipment | fortune | 0.091 |
| 127 | Cinder Salt Armor | epic | charm | armor | 0.091 |
| 128 | Cinder Solemn Focus | epic | consumable | crit | 0.091 |
| 129 | Cinder Bell Echo | epic | relic | chain | 0.091 |
| 130 | Cinder Shock Shell | epic | equipment | splash | 0.091 |
| 131 | Cinder Lamp Oil | epic | charm | burn | 0.091 |
| 132 | Cinder Frost Brine | epic | consumable | slow | 0.091 |
| 133 | Cinder Deep Pockets | epic | relic | coins | 0.091 |
| 134 | Cinder Diver’s Lung | epic | equipment | regen | 0.39 |
| 135 | Cinder Anchorstep | epic | charm | dodge | 0.091 |
| 136 | Cinder Lighthouse Prism | epic | consumable | projectiles | 0.34 |
| 137 | Cinder Exorcist | epic | relic | bossDamage | 0.091 |
| 138 | Cinder Tide Drain | epic | equipment | lifesteal | 0.091 |
| 139 | Cinder Cartographer | epic | charm | secrets | 58 |
| 140 | Cinder Shrine Prayer | epic | consumable | xp | 0.091 |
| 141 | Ossuary Power | epic | relic | power | 0.102 |
| 142 | Ossuary Heart | epic | equipment | health | 42 |
| 143 | Ossuary Sea Legs | epic | charm | speed | 0.102 |
| 144 | Ossuary Quick Wick | epic | consumable | rate | 0.102 |
| 145 | Ossuary Far Light | epic | relic | range | 0.102 |
| 146 | Ossuary Scavenger | epic | equipment | fortune | 0.102 |
| 147 | Ossuary Salt Armor | epic | charm | armor | 0.102 |
| 148 | Ossuary Solemn Focus | epic | consumable | crit | 0.102 |
| 149 | Ossuary Bell Echo | epic | relic | chain | 0.102 |
| 150 | Ossuary Shock Shell | epic | equipment | splash | 0.102 |
| 151 | Ossuary Lamp Oil | epic | charm | burn | 0.102 |
| 152 | Ossuary Frost Brine | epic | consumable | slow | 0.102 |
| 153 | Ossuary Deep Pockets | epic | relic | coins | 0.102 |
| 154 | Ossuary Diver’s Lung | epic | equipment | regen | 0.44 |
| 155 | Ossuary Anchorstep | epic | charm | dodge | 0.102 |
| 156 | Ossuary Lighthouse Prism | epic | consumable | projectiles | 0.38 |
| 157 | Ossuary Exorcist | epic | relic | bossDamage | 0.102 |
| 158 | Ossuary Tide Drain | epic | equipment | lifesteal | 0.102 |
| 159 | Ossuary Cartographer | epic | charm | secrets | 65 |
| 160 | Ossuary Shrine Prayer | epic | consumable | xp | 0.102 |
| 161 | Prismatic Power | legendary | relic | power | 0.113 |
| 162 | Prismatic Heart | legendary | equipment | health | 47 |
| 163 | Prismatic Sea Legs | legendary | charm | speed | 0.113 |
| 164 | Prismatic Quick Wick | legendary | consumable | rate | 0.113 |
| 165 | Prismatic Far Light | legendary | relic | range | 0.113 |
| 166 | Prismatic Scavenger | legendary | equipment | fortune | 0.113 |
| 167 | Prismatic Salt Armor | legendary | charm | armor | 0.113 |
| 168 | Prismatic Solemn Focus | legendary | consumable | crit | 0.113 |
| 169 | Prismatic Bell Echo | legendary | relic | chain | 0.113 |
| 170 | Prismatic Shock Shell | legendary | equipment | splash | 0.113 |
| 171 | Prismatic Lamp Oil | legendary | charm | burn | 0.113 |
| 172 | Prismatic Frost Brine | legendary | consumable | slow | 0.113 |
| 173 | Prismatic Deep Pockets | legendary | relic | coins | 0.113 |
| 174 | Prismatic Diver’s Lung | legendary | equipment | regen | 0.49 |
| 175 | Prismatic Anchorstep | legendary | charm | dodge | 0.113 |
| 176 | Prismatic Lighthouse Prism | legendary | consumable | projectiles | 0.42 |
| 177 | Prismatic Exorcist | legendary | relic | bossDamage | 0.113 |
| 178 | Prismatic Tide Drain | legendary | equipment | lifesteal | 0.113 |
| 179 | Prismatic Cartographer | legendary | charm | secrets | 72 |
| 180 | Prismatic Shrine Prayer | legendary | consumable | xp | 0.113 |
| 181 | Abyssal Power | legendary | relic | power | 0.124 |
| 182 | Abyssal Heart | legendary | equipment | health | 52 |
| 183 | Abyssal Sea Legs | legendary | charm | speed | 0.124 |
| 184 | Abyssal Quick Wick | legendary | consumable | rate | 0.124 |
| 185 | Abyssal Far Light | legendary | relic | range | 0.124 |
| 186 | Abyssal Scavenger | legendary | equipment | fortune | 0.124 |
| 187 | Abyssal Salt Armor | legendary | charm | armor | 0.124 |
| 188 | Abyssal Solemn Focus | legendary | consumable | crit | 0.124 |
| 189 | Abyssal Bell Echo | legendary | relic | chain | 0.124 |
| 190 | Abyssal Shock Shell | legendary | equipment | splash | 0.124 |
| 191 | Abyssal Lamp Oil | legendary | charm | burn | 0.124 |
| 192 | Abyssal Frost Brine | legendary | consumable | slow | 0.124 |
| 193 | Abyssal Deep Pockets | legendary | relic | coins | 0.124 |
| 194 | Abyssal Diver’s Lung | legendary | equipment | regen | 0.54 |
| 195 | Abyssal Anchorstep | legendary | charm | dodge | 0.124 |
| 196 | Abyssal Lighthouse Prism | legendary | consumable | projectiles | 0.46 |
| 197 | Abyssal Exorcist | legendary | relic | bossDamage | 0.124 |
| 198 | Abyssal Tide Drain | legendary | equipment | lifesteal | 0.124 |
| 199 | Abyssal Cartographer | legendary | charm | secrets | 79 |
| 200 | Abyssal Shrine Prayer | legendary | consumable | xp | 0.124 |