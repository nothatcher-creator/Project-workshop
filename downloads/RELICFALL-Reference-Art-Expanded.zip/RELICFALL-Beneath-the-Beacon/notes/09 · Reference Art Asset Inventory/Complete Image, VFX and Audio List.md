# Every Asset to Locate, Design, or Generate

This list contains 379 explicitly scoped assets. There are **no blank sprite grids**.

| Path | Description | Status |
|---|---|---|
| `prototype/assets/keeper-reference.webp` | Player portrait and sprite reference | created-from-user-reference |
| `prototype/assets/leviathan-boss.webp` | Floor 8 boss reference | created-from-user-reference |
| `prototype/assets/gearworks-reference.webp` | Machinery and ceiling reference | created-from-user-reference |
| `prototype/assets/descent-reference.webp` | Lighthouse vertical descent reference | created-from-user-reference |
| `prototype/assets/abyss-reference.webp` | Underwater/hell reference | created-from-user-reference |
| `prototype/assets/depth-01.webp` | Floor 1 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-02.webp` | Floor 2 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-03.webp` | Floor 3 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-04.webp` | Floor 4 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-05.webp` | Floor 5 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-06.webp` | Floor 6 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-07.webp` | Floor 7 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-08.webp` | Floor 8 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `prototype/assets/depth-09.webp` | Floor 9 environmental layer / derived from the lighthouse cross-section art | created-from-user-reference |
| `future-art/bosses/boss-01-turnaround.png` | Full top-down transparent boss art for The Bellwright | needs-reference-derived-generation |
| `future-art/enemies/enemy-1-1-topdown.png` | Transparent combat-view enemy art: Lamp Moth | needs-reference-derived-generation |
| `future-art/enemies/enemy-1-2-topdown.png` | Transparent combat-view enemy art: Dust Rat | needs-reference-derived-generation |
| `future-art/enemies/enemy-1-3-topdown.png` | Transparent combat-view enemy art: Oil Drip | needs-reference-derived-generation |
| `future-art/backgrounds/floor-01-tiles.png` | Seamless usable gameplay floor textures for Keeper’s Quarters | needs-reference-derived-generation |
| `future-art/bosses/boss-02-turnaround.png` | Full top-down transparent boss art for The Bilge Mother | needs-reference-derived-generation |
| `future-art/enemies/enemy-2-1-topdown.png` | Transparent combat-view enemy art: Barnacle Skitter | needs-reference-derived-generation |
| `future-art/enemies/enemy-2-2-topdown.png` | Transparent combat-view enemy art: Valve Leech | needs-reference-derived-generation |
| `future-art/enemies/enemy-2-3-topdown.png` | Transparent combat-view enemy art: Pressure Wraith | needs-reference-derived-generation |
| `future-art/backgrounds/floor-02-tiles.png` | Seamless usable gameplay floor textures for Flooded Maintenance | needs-reference-derived-generation |
| `future-art/bosses/boss-03-turnaround.png` | Full top-down transparent boss art for Saint of Brine | needs-reference-derived-generation |
| `future-art/enemies/enemy-3-1-topdown.png` | Transparent combat-view enemy art: Chalk Acolyte | needs-reference-derived-generation |
| `future-art/enemies/enemy-3-2-topdown.png` | Transparent combat-view enemy art: Pale Mourner | needs-reference-derived-generation |
| `future-art/enemies/enemy-3-3-topdown.png` | Transparent combat-view enemy art: Reliquary Crab | needs-reference-derived-generation |
| `future-art/backgrounds/floor-03-tiles.png` | Seamless usable gameplay floor textures for Salt Chapel | needs-reference-derived-generation |
| `future-art/bosses/boss-04-turnaround.png` | Full top-down transparent boss art for Mycelium Admiral | needs-reference-derived-generation |
| `future-art/enemies/enemy-4-1-topdown.png` | Transparent combat-view enemy art: Spore Husk | needs-reference-derived-generation |
| `future-art/enemies/enemy-4-2-topdown.png` | Transparent combat-view enemy art: Fungal Blink | needs-reference-derived-generation |
| `future-art/enemies/enemy-4-3-topdown.png` | Transparent combat-view enemy art: Bedframe Stalker | needs-reference-derived-generation |
| `future-art/backgrounds/floor-04-tiles.png` | Seamless usable gameplay floor textures for Molded Bunks | needs-reference-derived-generation |
| `future-art/bosses/boss-05-turnaround.png` | Full top-down transparent boss art for The Furnace Warden | needs-reference-derived-generation |
| `future-art/enemies/enemy-5-1-topdown.png` | Transparent combat-view enemy art: Cinder Imp | needs-reference-derived-generation |
| `future-art/enemies/enemy-5-2-topdown.png` | Transparent combat-view enemy art: Coal Golem | needs-reference-derived-generation |
| `future-art/enemies/enemy-5-3-topdown.png` | Transparent combat-view enemy art: Chain Spark | needs-reference-derived-generation |
| `future-art/backgrounds/floor-05-tiles.png` | Seamless usable gameplay floor textures for Brass Inferno | needs-reference-derived-generation |
| `future-art/bosses/boss-06-turnaround.png` | Full top-down transparent boss art for The Sunken Choir | needs-reference-derived-generation |
| `future-art/enemies/enemy-6-1-topdown.png` | Transparent combat-view enemy art: Skull Lantern | needs-reference-derived-generation |
| `future-art/enemies/enemy-6-2-topdown.png` | Transparent combat-view enemy art: Drowned Gunner | needs-reference-derived-generation |
| `future-art/enemies/enemy-6-3-topdown.png` | Transparent combat-view enemy art: Bone Eel | needs-reference-derived-generation |
| `future-art/backgrounds/floor-06-tiles.png` | Seamless usable gameplay floor textures for Drowned Ossuary | needs-reference-derived-generation |
| `future-art/bosses/boss-07-turnaround.png` | Full top-down transparent boss art for The Glass Matriarch | needs-reference-derived-generation |
| `future-art/enemies/enemy-7-1-topdown.png` | Transparent combat-view enemy art: Lens Phantom | needs-reference-derived-generation |
| `future-art/enemies/enemy-7-2-topdown.png` | Transparent combat-view enemy art: Mirror Hound | needs-reference-derived-generation |
| `future-art/enemies/enemy-7-3-topdown.png` | Transparent combat-view enemy art: Prism Eye | needs-reference-derived-generation |
| `future-art/backgrounds/floor-07-tiles.png` | Seamless usable gameplay floor textures for The False Lens | needs-reference-derived-generation |
| `future-art/bosses/boss-08-turnaround.png` | Full top-down transparent boss art for The Abyssal Leviathan | needs-reference-derived-generation |
| `future-art/enemies/enemy-8-1-topdown.png` | Transparent combat-view enemy art: Ink Revenant | needs-reference-derived-generation |
| `future-art/enemies/enemy-8-2-topdown.png` | Transparent combat-view enemy art: Deepwake Hunter | needs-reference-derived-generation |
| `future-art/enemies/enemy-8-3-topdown.png` | Transparent combat-view enemy art: Void Angler | needs-reference-derived-generation |
| `future-art/backgrounds/floor-08-tiles.png` | Seamless usable gameplay floor textures for The Black Tide | needs-reference-derived-generation |
| `future-art/bosses/boss-09-turnaround.png` | Full top-down transparent boss art for The First Keeper | needs-reference-derived-generation |
| `future-art/enemies/enemy-9-1-topdown.png` | Transparent combat-view enemy art: Hellglass Sentinel | needs-reference-derived-generation |
| `future-art/enemies/enemy-9-2-topdown.png` | Transparent combat-view enemy art: Molten Seraph | needs-reference-derived-generation |
| `future-art/enemies/enemy-9-3-topdown.png` | Transparent combat-view enemy art: Ash Chronist | needs-reference-derived-generation |
| `future-art/backgrounds/floor-09-tiles.png` | Seamless usable gameplay floor textures for The Buried Sun | needs-reference-derived-generation |
| `future-art/weapons/weapon-0-0.png` | Agent-made transparent combat icon for The Wickpiercer | needs-reference-derived-generation |
| `future-art/weapons/weapon-0-1.png` | Agent-made transparent combat icon for Tidebreaker Harpoon | needs-reference-derived-generation |
| `future-art/weapons/weapon-0-2.png` | Agent-made transparent combat icon for The Gilded Nail | needs-reference-derived-generation |
| `future-art/weapons/weapon-1-0.png` | Agent-made transparent combat icon for Mournwood Bow | needs-reference-derived-generation |
| `future-art/weapons/weapon-1-1.png` | Agent-made transparent combat icon for Saltwind Recurve | needs-reference-derived-generation |
| `future-art/weapons/weapon-1-2.png` | Agent-made transparent combat icon for The Cinderbranch | needs-reference-derived-generation |
| `future-art/weapons/weapon-2-0.png` | Agent-made transparent combat icon for Choir Staff | needs-reference-derived-generation |
| `future-art/weapons/weapon-2-1.png` | Agent-made transparent combat icon for Lantern Rod | needs-reference-derived-generation |
| `future-art/weapons/weapon-2-2.png` | Agent-made transparent combat icon for Blacktide Scepter | needs-reference-derived-generation |
| `future-art/weapons/weapon-3-0.png` | Agent-made transparent combat icon for Barnacle Tome | needs-reference-derived-generation |
| `future-art/weapons/weapon-3-1.png` | Agent-made transparent combat icon for Choir of Lanterns | needs-reference-derived-generation |
| `future-art/weapons/weapon-3-2.png` | Agent-made transparent combat icon for The Husk Reliquary | needs-reference-derived-generation |
| `future-art/weapons/weapon-4-0.png` | Agent-made transparent combat icon for Gale Cutlass | needs-reference-derived-generation |
| `future-art/weapons/weapon-4-1.png` | Agent-made transparent combat icon for Keeper’s Oath | needs-reference-derived-generation |
| `future-art/weapons/weapon-4-2.png` | Agent-made transparent combat icon for Anchor of Souls | needs-reference-derived-generation |
| `future-art/weapons/weapon-5-0.png` | Agent-made transparent combat icon for Pier Glass | needs-reference-derived-generation |
| `future-art/weapons/weapon-5-1.png` | Agent-made transparent combat icon for Rustlock Repeater | needs-reference-derived-generation |
| `future-art/weapons/weapon-5-2.png` | Agent-made transparent combat icon for Furnace Bolt | needs-reference-derived-generation |
| `future-art/weapons/weapon-6-0.png` | Agent-made transparent combat icon for Oculus of Foam | needs-reference-derived-generation |
| `future-art/weapons/weapon-6-1.png` | Agent-made transparent combat icon for The False Moon | needs-reference-derived-generation |
| `future-art/weapons/weapon-6-2.png` | Agent-made transparent combat icon for Undertow Eye | needs-reference-derived-generation |
| `future-art/weapons/weapon-7-0.png` | Agent-made transparent combat icon for Pilgrim Lens | needs-reference-derived-generation |
| `future-art/weapons/weapon-7-1.png` | Agent-made transparent combat icon for Sunspindle | needs-reference-derived-generation |
| `future-art/weapons/weapon-7-2.png` | Agent-made transparent combat icon for The White Seam | needs-reference-derived-generation |
| `future-art/weapons/weapon-8-0.png` | Agent-made transparent combat icon for Brine Flask | needs-reference-derived-generation |
| `future-art/weapons/weapon-8-1.png` | Agent-made transparent combat icon for Ash Bombard | needs-reference-derived-generation |
| `future-art/weapons/weapon-8-2.png` | Agent-made transparent combat icon for The Black Oil | needs-reference-derived-generation |
| `future-art/weapons/weapon-9-0.png` | Agent-made transparent combat icon for Storm Lantern | needs-reference-derived-generation |
| `future-art/weapons/weapon-9-1.png` | Agent-made transparent combat icon for Dirge Beacon | needs-reference-derived-generation |
| `future-art/weapons/weapon-9-2.png` | Agent-made transparent combat icon for The First Flame | needs-reference-derived-generation |
| `future-art/vfx/harpoon-attack.png` | Art-driven attack visuals harpoon | needs-reference-derived-generation |
| `future-art/vfx/bow-attack.png` | Art-driven attack visuals bow | needs-reference-derived-generation |
| `future-art/vfx/staff-attack.png` | Art-driven attack visuals staff | needs-reference-derived-generation |
| `future-art/vfx/summoner-attack.png` | Art-driven attack visuals summoner | needs-reference-derived-generation |
| `future-art/vfx/blade-attack.png` | Art-driven attack visuals blade | needs-reference-derived-generation |
| `future-art/vfx/crossbow-attack.png` | Art-driven attack visuals crossbow | needs-reference-derived-generation |
| `future-art/vfx/orb-attack.png` | Art-driven attack visuals orb | needs-reference-derived-generation |
| `future-art/vfx/beam-attack.png` | Art-driven attack visuals beam | needs-reference-derived-generation |
| `future-art/vfx/thrower-attack.png` | Art-driven attack visuals thrower | needs-reference-derived-generation |
| `future-art/vfx/lantern-attack.png` | Art-driven attack visuals lantern | needs-reference-derived-generation |
| `future-art/ui/menu-logo.png` | menu logo reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/shopkeeper.png` | shopkeeper reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/chest-closed.png` | chest closed reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/chest-open.png` | chest open reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/secret-door.png` | secret door reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/tutorial-illustrations.png` | tutorial illustrations reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/boss-healthbar.png` | boss healthbar reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/loot-beam.png` | loot beam reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/achievement-icons.png` | achievement icons reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/coin.png` | coin reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/player-dodge-ghost.png` | player dodge ghost reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/player-hit.png` | player hit reference-driven asset | needs-reference-derived-generation |
| `future-art/ui/level-transition.png` | level transition reference-driven asset | needs-reference-derived-generation |
| `future-art/items/item-001.png` | Inventory icon with recognizable shape for Copper Power | needs-reference-derived-generation |
| `future-art/items/item-002.png` | Inventory icon with recognizable shape for Copper Heart | needs-reference-derived-generation |
| `future-art/items/item-003.png` | Inventory icon with recognizable shape for Copper Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-004.png` | Inventory icon with recognizable shape for Copper Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-005.png` | Inventory icon with recognizable shape for Copper Far Light | needs-reference-derived-generation |
| `future-art/items/item-006.png` | Inventory icon with recognizable shape for Copper Scavenger | needs-reference-derived-generation |
| `future-art/items/item-007.png` | Inventory icon with recognizable shape for Copper Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-008.png` | Inventory icon with recognizable shape for Copper Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-009.png` | Inventory icon with recognizable shape for Copper Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-010.png` | Inventory icon with recognizable shape for Copper Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-011.png` | Inventory icon with recognizable shape for Copper Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-012.png` | Inventory icon with recognizable shape for Copper Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-013.png` | Inventory icon with recognizable shape for Copper Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-014.png` | Inventory icon with recognizable shape for Copper Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-015.png` | Inventory icon with recognizable shape for Copper Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-016.png` | Inventory icon with recognizable shape for Copper Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-017.png` | Inventory icon with recognizable shape for Copper Exorcist | needs-reference-derived-generation |
| `future-art/items/item-018.png` | Inventory icon with recognizable shape for Copper Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-019.png` | Inventory icon with recognizable shape for Copper Cartographer | needs-reference-derived-generation |
| `future-art/items/item-020.png` | Inventory icon with recognizable shape for Copper Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-021.png` | Inventory icon with recognizable shape for Brine-Stained Power | needs-reference-derived-generation |
| `future-art/items/item-022.png` | Inventory icon with recognizable shape for Brine-Stained Heart | needs-reference-derived-generation |
| `future-art/items/item-023.png` | Inventory icon with recognizable shape for Brine-Stained Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-024.png` | Inventory icon with recognizable shape for Brine-Stained Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-025.png` | Inventory icon with recognizable shape for Brine-Stained Far Light | needs-reference-derived-generation |
| `future-art/items/item-026.png` | Inventory icon with recognizable shape for Brine-Stained Scavenger | needs-reference-derived-generation |
| `future-art/items/item-027.png` | Inventory icon with recognizable shape for Brine-Stained Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-028.png` | Inventory icon with recognizable shape for Brine-Stained Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-029.png` | Inventory icon with recognizable shape for Brine-Stained Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-030.png` | Inventory icon with recognizable shape for Brine-Stained Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-031.png` | Inventory icon with recognizable shape for Brine-Stained Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-032.png` | Inventory icon with recognizable shape for Brine-Stained Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-033.png` | Inventory icon with recognizable shape for Brine-Stained Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-034.png` | Inventory icon with recognizable shape for Brine-Stained Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-035.png` | Inventory icon with recognizable shape for Brine-Stained Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-036.png` | Inventory icon with recognizable shape for Brine-Stained Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-037.png` | Inventory icon with recognizable shape for Brine-Stained Exorcist | needs-reference-derived-generation |
| `future-art/items/item-038.png` | Inventory icon with recognizable shape for Brine-Stained Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-039.png` | Inventory icon with recognizable shape for Brine-Stained Cartographer | needs-reference-derived-generation |
| `future-art/items/item-040.png` | Inventory icon with recognizable shape for Brine-Stained Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-041.png` | Inventory icon with recognizable shape for Keeper’s Power | needs-reference-derived-generation |
| `future-art/items/item-042.png` | Inventory icon with recognizable shape for Keeper’s Heart | needs-reference-derived-generation |
| `future-art/items/item-043.png` | Inventory icon with recognizable shape for Keeper’s Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-044.png` | Inventory icon with recognizable shape for Keeper’s Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-045.png` | Inventory icon with recognizable shape for Keeper’s Far Light | needs-reference-derived-generation |
| `future-art/items/item-046.png` | Inventory icon with recognizable shape for Keeper’s Scavenger | needs-reference-derived-generation |
| `future-art/items/item-047.png` | Inventory icon with recognizable shape for Keeper’s Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-048.png` | Inventory icon with recognizable shape for Keeper’s Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-049.png` | Inventory icon with recognizable shape for Keeper’s Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-050.png` | Inventory icon with recognizable shape for Keeper’s Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-051.png` | Inventory icon with recognizable shape for Keeper’s Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-052.png` | Inventory icon with recognizable shape for Keeper’s Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-053.png` | Inventory icon with recognizable shape for Keeper’s Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-054.png` | Inventory icon with recognizable shape for Keeper’s Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-055.png` | Inventory icon with recognizable shape for Keeper’s Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-056.png` | Inventory icon with recognizable shape for Keeper’s Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-057.png` | Inventory icon with recognizable shape for Keeper’s Exorcist | needs-reference-derived-generation |
| `future-art/items/item-058.png` | Inventory icon with recognizable shape for Keeper’s Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-059.png` | Inventory icon with recognizable shape for Keeper’s Cartographer | needs-reference-derived-generation |
| `future-art/items/item-060.png` | Inventory icon with recognizable shape for Keeper’s Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-061.png` | Inventory icon with recognizable shape for Floodborn Power | needs-reference-derived-generation |
| `future-art/items/item-062.png` | Inventory icon with recognizable shape for Floodborn Heart | needs-reference-derived-generation |
| `future-art/items/item-063.png` | Inventory icon with recognizable shape for Floodborn Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-064.png` | Inventory icon with recognizable shape for Floodborn Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-065.png` | Inventory icon with recognizable shape for Floodborn Far Light | needs-reference-derived-generation |
| `future-art/items/item-066.png` | Inventory icon with recognizable shape for Floodborn Scavenger | needs-reference-derived-generation |
| `future-art/items/item-067.png` | Inventory icon with recognizable shape for Floodborn Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-068.png` | Inventory icon with recognizable shape for Floodborn Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-069.png` | Inventory icon with recognizable shape for Floodborn Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-070.png` | Inventory icon with recognizable shape for Floodborn Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-071.png` | Inventory icon with recognizable shape for Floodborn Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-072.png` | Inventory icon with recognizable shape for Floodborn Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-073.png` | Inventory icon with recognizable shape for Floodborn Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-074.png` | Inventory icon with recognizable shape for Floodborn Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-075.png` | Inventory icon with recognizable shape for Floodborn Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-076.png` | Inventory icon with recognizable shape for Floodborn Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-077.png` | Inventory icon with recognizable shape for Floodborn Exorcist | needs-reference-derived-generation |
| `future-art/items/item-078.png` | Inventory icon with recognizable shape for Floodborn Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-079.png` | Inventory icon with recognizable shape for Floodborn Cartographer | needs-reference-derived-generation |
| `future-art/items/item-080.png` | Inventory icon with recognizable shape for Floodborn Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-081.png` | Inventory icon with recognizable shape for Saltbound Power | needs-reference-derived-generation |
| `future-art/items/item-082.png` | Inventory icon with recognizable shape for Saltbound Heart | needs-reference-derived-generation |
| `future-art/items/item-083.png` | Inventory icon with recognizable shape for Saltbound Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-084.png` | Inventory icon with recognizable shape for Saltbound Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-085.png` | Inventory icon with recognizable shape for Saltbound Far Light | needs-reference-derived-generation |
| `future-art/items/item-086.png` | Inventory icon with recognizable shape for Saltbound Scavenger | needs-reference-derived-generation |
| `future-art/items/item-087.png` | Inventory icon with recognizable shape for Saltbound Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-088.png` | Inventory icon with recognizable shape for Saltbound Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-089.png` | Inventory icon with recognizable shape for Saltbound Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-090.png` | Inventory icon with recognizable shape for Saltbound Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-091.png` | Inventory icon with recognizable shape for Saltbound Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-092.png` | Inventory icon with recognizable shape for Saltbound Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-093.png` | Inventory icon with recognizable shape for Saltbound Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-094.png` | Inventory icon with recognizable shape for Saltbound Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-095.png` | Inventory icon with recognizable shape for Saltbound Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-096.png` | Inventory icon with recognizable shape for Saltbound Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-097.png` | Inventory icon with recognizable shape for Saltbound Exorcist | needs-reference-derived-generation |
| `future-art/items/item-098.png` | Inventory icon with recognizable shape for Saltbound Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-099.png` | Inventory icon with recognizable shape for Saltbound Cartographer | needs-reference-derived-generation |
| `future-art/items/item-100.png` | Inventory icon with recognizable shape for Saltbound Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-101.png` | Inventory icon with recognizable shape for Fungal Power | needs-reference-derived-generation |
| `future-art/items/item-102.png` | Inventory icon with recognizable shape for Fungal Heart | needs-reference-derived-generation |
| `future-art/items/item-103.png` | Inventory icon with recognizable shape for Fungal Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-104.png` | Inventory icon with recognizable shape for Fungal Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-105.png` | Inventory icon with recognizable shape for Fungal Far Light | needs-reference-derived-generation |
| `future-art/items/item-106.png` | Inventory icon with recognizable shape for Fungal Scavenger | needs-reference-derived-generation |
| `future-art/items/item-107.png` | Inventory icon with recognizable shape for Fungal Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-108.png` | Inventory icon with recognizable shape for Fungal Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-109.png` | Inventory icon with recognizable shape for Fungal Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-110.png` | Inventory icon with recognizable shape for Fungal Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-111.png` | Inventory icon with recognizable shape for Fungal Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-112.png` | Inventory icon with recognizable shape for Fungal Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-113.png` | Inventory icon with recognizable shape for Fungal Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-114.png` | Inventory icon with recognizable shape for Fungal Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-115.png` | Inventory icon with recognizable shape for Fungal Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-116.png` | Inventory icon with recognizable shape for Fungal Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-117.png` | Inventory icon with recognizable shape for Fungal Exorcist | needs-reference-derived-generation |
| `future-art/items/item-118.png` | Inventory icon with recognizable shape for Fungal Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-119.png` | Inventory icon with recognizable shape for Fungal Cartographer | needs-reference-derived-generation |
| `future-art/items/item-120.png` | Inventory icon with recognizable shape for Fungal Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-121.png` | Inventory icon with recognizable shape for Cinder Power | needs-reference-derived-generation |
| `future-art/items/item-122.png` | Inventory icon with recognizable shape for Cinder Heart | needs-reference-derived-generation |
| `future-art/items/item-123.png` | Inventory icon with recognizable shape for Cinder Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-124.png` | Inventory icon with recognizable shape for Cinder Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-125.png` | Inventory icon with recognizable shape for Cinder Far Light | needs-reference-derived-generation |
| `future-art/items/item-126.png` | Inventory icon with recognizable shape for Cinder Scavenger | needs-reference-derived-generation |
| `future-art/items/item-127.png` | Inventory icon with recognizable shape for Cinder Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-128.png` | Inventory icon with recognizable shape for Cinder Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-129.png` | Inventory icon with recognizable shape for Cinder Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-130.png` | Inventory icon with recognizable shape for Cinder Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-131.png` | Inventory icon with recognizable shape for Cinder Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-132.png` | Inventory icon with recognizable shape for Cinder Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-133.png` | Inventory icon with recognizable shape for Cinder Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-134.png` | Inventory icon with recognizable shape for Cinder Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-135.png` | Inventory icon with recognizable shape for Cinder Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-136.png` | Inventory icon with recognizable shape for Cinder Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-137.png` | Inventory icon with recognizable shape for Cinder Exorcist | needs-reference-derived-generation |
| `future-art/items/item-138.png` | Inventory icon with recognizable shape for Cinder Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-139.png` | Inventory icon with recognizable shape for Cinder Cartographer | needs-reference-derived-generation |
| `future-art/items/item-140.png` | Inventory icon with recognizable shape for Cinder Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-141.png` | Inventory icon with recognizable shape for Ossuary Power | needs-reference-derived-generation |
| `future-art/items/item-142.png` | Inventory icon with recognizable shape for Ossuary Heart | needs-reference-derived-generation |
| `future-art/items/item-143.png` | Inventory icon with recognizable shape for Ossuary Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-144.png` | Inventory icon with recognizable shape for Ossuary Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-145.png` | Inventory icon with recognizable shape for Ossuary Far Light | needs-reference-derived-generation |
| `future-art/items/item-146.png` | Inventory icon with recognizable shape for Ossuary Scavenger | needs-reference-derived-generation |
| `future-art/items/item-147.png` | Inventory icon with recognizable shape for Ossuary Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-148.png` | Inventory icon with recognizable shape for Ossuary Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-149.png` | Inventory icon with recognizable shape for Ossuary Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-150.png` | Inventory icon with recognizable shape for Ossuary Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-151.png` | Inventory icon with recognizable shape for Ossuary Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-152.png` | Inventory icon with recognizable shape for Ossuary Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-153.png` | Inventory icon with recognizable shape for Ossuary Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-154.png` | Inventory icon with recognizable shape for Ossuary Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-155.png` | Inventory icon with recognizable shape for Ossuary Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-156.png` | Inventory icon with recognizable shape for Ossuary Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-157.png` | Inventory icon with recognizable shape for Ossuary Exorcist | needs-reference-derived-generation |
| `future-art/items/item-158.png` | Inventory icon with recognizable shape for Ossuary Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-159.png` | Inventory icon with recognizable shape for Ossuary Cartographer | needs-reference-derived-generation |
| `future-art/items/item-160.png` | Inventory icon with recognizable shape for Ossuary Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-161.png` | Inventory icon with recognizable shape for Prismatic Power | needs-reference-derived-generation |
| `future-art/items/item-162.png` | Inventory icon with recognizable shape for Prismatic Heart | needs-reference-derived-generation |
| `future-art/items/item-163.png` | Inventory icon with recognizable shape for Prismatic Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-164.png` | Inventory icon with recognizable shape for Prismatic Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-165.png` | Inventory icon with recognizable shape for Prismatic Far Light | needs-reference-derived-generation |
| `future-art/items/item-166.png` | Inventory icon with recognizable shape for Prismatic Scavenger | needs-reference-derived-generation |
| `future-art/items/item-167.png` | Inventory icon with recognizable shape for Prismatic Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-168.png` | Inventory icon with recognizable shape for Prismatic Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-169.png` | Inventory icon with recognizable shape for Prismatic Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-170.png` | Inventory icon with recognizable shape for Prismatic Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-171.png` | Inventory icon with recognizable shape for Prismatic Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-172.png` | Inventory icon with recognizable shape for Prismatic Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-173.png` | Inventory icon with recognizable shape for Prismatic Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-174.png` | Inventory icon with recognizable shape for Prismatic Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-175.png` | Inventory icon with recognizable shape for Prismatic Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-176.png` | Inventory icon with recognizable shape for Prismatic Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-177.png` | Inventory icon with recognizable shape for Prismatic Exorcist | needs-reference-derived-generation |
| `future-art/items/item-178.png` | Inventory icon with recognizable shape for Prismatic Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-179.png` | Inventory icon with recognizable shape for Prismatic Cartographer | needs-reference-derived-generation |
| `future-art/items/item-180.png` | Inventory icon with recognizable shape for Prismatic Shrine Prayer | needs-reference-derived-generation |
| `future-art/items/item-181.png` | Inventory icon with recognizable shape for Abyssal Power | needs-reference-derived-generation |
| `future-art/items/item-182.png` | Inventory icon with recognizable shape for Abyssal Heart | needs-reference-derived-generation |
| `future-art/items/item-183.png` | Inventory icon with recognizable shape for Abyssal Sea Legs | needs-reference-derived-generation |
| `future-art/items/item-184.png` | Inventory icon with recognizable shape for Abyssal Quick Wick | needs-reference-derived-generation |
| `future-art/items/item-185.png` | Inventory icon with recognizable shape for Abyssal Far Light | needs-reference-derived-generation |
| `future-art/items/item-186.png` | Inventory icon with recognizable shape for Abyssal Scavenger | needs-reference-derived-generation |
| `future-art/items/item-187.png` | Inventory icon with recognizable shape for Abyssal Salt Armor | needs-reference-derived-generation |
| `future-art/items/item-188.png` | Inventory icon with recognizable shape for Abyssal Solemn Focus | needs-reference-derived-generation |
| `future-art/items/item-189.png` | Inventory icon with recognizable shape for Abyssal Bell Echo | needs-reference-derived-generation |
| `future-art/items/item-190.png` | Inventory icon with recognizable shape for Abyssal Shock Shell | needs-reference-derived-generation |
| `future-art/items/item-191.png` | Inventory icon with recognizable shape for Abyssal Lamp Oil | needs-reference-derived-generation |
| `future-art/items/item-192.png` | Inventory icon with recognizable shape for Abyssal Frost Brine | needs-reference-derived-generation |
| `future-art/items/item-193.png` | Inventory icon with recognizable shape for Abyssal Deep Pockets | needs-reference-derived-generation |
| `future-art/items/item-194.png` | Inventory icon with recognizable shape for Abyssal Diver’s Lung | needs-reference-derived-generation |
| `future-art/items/item-195.png` | Inventory icon with recognizable shape for Abyssal Anchorstep | needs-reference-derived-generation |
| `future-art/items/item-196.png` | Inventory icon with recognizable shape for Abyssal Lighthouse Prism | needs-reference-derived-generation |
| `future-art/items/item-197.png` | Inventory icon with recognizable shape for Abyssal Exorcist | needs-reference-derived-generation |
| `future-art/items/item-198.png` | Inventory icon with recognizable shape for Abyssal Tide Drain | needs-reference-derived-generation |
| `future-art/items/item-199.png` | Inventory icon with recognizable shape for Abyssal Cartographer | needs-reference-derived-generation |
| `future-art/items/item-200.png` | Inventory icon with recognizable shape for Abyssal Shrine Prayer | needs-reference-derived-generation |
| `future-audio/ambient-01.ogg` | Ambient soundtrack for Keeper’s Quarters | needs-original-composition |
| `future-audio/boss-01.ogg` | Boss music for The Bellwright | needs-original-composition |
| `future-audio/ambient-02.ogg` | Ambient soundtrack for Flooded Maintenance | needs-original-composition |
| `future-audio/boss-02.ogg` | Boss music for The Bilge Mother | needs-original-composition |
| `future-audio/ambient-03.ogg` | Ambient soundtrack for Salt Chapel | needs-original-composition |
| `future-audio/boss-03.ogg` | Boss music for Saint of Brine | needs-original-composition |
| `future-audio/ambient-04.ogg` | Ambient soundtrack for Molded Bunks | needs-original-composition |
| `future-audio/boss-04.ogg` | Boss music for Mycelium Admiral | needs-original-composition |
| `future-audio/ambient-05.ogg` | Ambient soundtrack for Brass Inferno | needs-original-composition |
| `future-audio/boss-05.ogg` | Boss music for The Furnace Warden | needs-original-composition |
| `future-audio/ambient-06.ogg` | Ambient soundtrack for Drowned Ossuary | needs-original-composition |
| `future-audio/boss-06.ogg` | Boss music for The Sunken Choir | needs-original-composition |
| `future-audio/ambient-07.ogg` | Ambient soundtrack for The False Lens | needs-original-composition |
| `future-audio/boss-07.ogg` | Boss music for The Glass Matriarch | needs-original-composition |
| `future-audio/ambient-08.ogg` | Ambient soundtrack for The Black Tide | needs-original-composition |
| `future-audio/boss-08.ogg` | Boss music for The Abyssal Leviathan | needs-original-composition |
| `future-audio/ambient-09.ogg` | Ambient soundtrack for The Buried Sun | needs-original-composition |
| `future-audio/boss-09.ogg` | Boss music for The First Keeper | needs-original-composition |
| `future-audio/enemy-1-1-voice.ogg` | Distinct hit/attack/death sound kit for Lamp Moth | needs-original-sound |
| `future-audio/enemy-1-2-voice.ogg` | Distinct hit/attack/death sound kit for Dust Rat | needs-original-sound |
| `future-audio/enemy-1-3-voice.ogg` | Distinct hit/attack/death sound kit for Oil Drip | needs-original-sound |
| `future-audio/enemy-2-1-voice.ogg` | Distinct hit/attack/death sound kit for Barnacle Skitter | needs-original-sound |
| `future-audio/enemy-2-2-voice.ogg` | Distinct hit/attack/death sound kit for Valve Leech | needs-original-sound |
| `future-audio/enemy-2-3-voice.ogg` | Distinct hit/attack/death sound kit for Pressure Wraith | needs-original-sound |
| `future-audio/enemy-3-1-voice.ogg` | Distinct hit/attack/death sound kit for Chalk Acolyte | needs-original-sound |
| `future-audio/enemy-3-2-voice.ogg` | Distinct hit/attack/death sound kit for Pale Mourner | needs-original-sound |
| `future-audio/enemy-3-3-voice.ogg` | Distinct hit/attack/death sound kit for Reliquary Crab | needs-original-sound |
| `future-audio/enemy-4-1-voice.ogg` | Distinct hit/attack/death sound kit for Spore Husk | needs-original-sound |
| `future-audio/enemy-4-2-voice.ogg` | Distinct hit/attack/death sound kit for Fungal Blink | needs-original-sound |
| `future-audio/enemy-4-3-voice.ogg` | Distinct hit/attack/death sound kit for Bedframe Stalker | needs-original-sound |
| `future-audio/enemy-5-1-voice.ogg` | Distinct hit/attack/death sound kit for Cinder Imp | needs-original-sound |
| `future-audio/enemy-5-2-voice.ogg` | Distinct hit/attack/death sound kit for Coal Golem | needs-original-sound |
| `future-audio/enemy-5-3-voice.ogg` | Distinct hit/attack/death sound kit for Chain Spark | needs-original-sound |
| `future-audio/enemy-6-1-voice.ogg` | Distinct hit/attack/death sound kit for Skull Lantern | needs-original-sound |
| `future-audio/enemy-6-2-voice.ogg` | Distinct hit/attack/death sound kit for Drowned Gunner | needs-original-sound |
| `future-audio/enemy-6-3-voice.ogg` | Distinct hit/attack/death sound kit for Bone Eel | needs-original-sound |
| `future-audio/enemy-7-1-voice.ogg` | Distinct hit/attack/death sound kit for Lens Phantom | needs-original-sound |
| `future-audio/enemy-7-2-voice.ogg` | Distinct hit/attack/death sound kit for Mirror Hound | needs-original-sound |
| `future-audio/enemy-7-3-voice.ogg` | Distinct hit/attack/death sound kit for Prism Eye | needs-original-sound |
| `future-audio/enemy-8-1-voice.ogg` | Distinct hit/attack/death sound kit for Ink Revenant | needs-original-sound |
| `future-audio/enemy-8-2-voice.ogg` | Distinct hit/attack/death sound kit for Deepwake Hunter | needs-original-sound |
| `future-audio/enemy-8-3-voice.ogg` | Distinct hit/attack/death sound kit for Void Angler | needs-original-sound |
| `future-audio/enemy-9-1-voice.ogg` | Distinct hit/attack/death sound kit for Hellglass Sentinel | needs-original-sound |
| `future-audio/enemy-9-2-voice.ogg` | Distinct hit/attack/death sound kit for Molten Seraph | needs-original-sound |
| `future-audio/enemy-9-3-voice.ogg` | Distinct hit/attack/death sound kit for Ash Chronist | needs-original-sound |
| `future-audio/coin.ogg` | coin sound | needs-original-sound |
| `future-audio/item-pickup.ogg` | item pickup sound | needs-original-sound |
| `future-audio/dodge.ogg` | dodge sound | needs-original-sound |
| `future-audio/room-clear.ogg` | room clear sound | needs-original-sound |
| `future-audio/portal.ogg` | portal sound | needs-original-sound |
| `future-audio/menu-select.ogg` | menu select sound | needs-original-sound |
| `future-audio/purchase.ogg` | purchase sound | needs-original-sound |
| `future-audio/secret-open.ogg` | secret open sound | needs-original-sound |
| `future-audio/chest-open.ogg` | chest open sound | needs-original-sound |
| `future-audio/death.ogg` | death sound | needs-original-sound |
| `future-audio/level-up.ogg` | level up sound | needs-original-sound |
| `future-audio/achievement.ogg` | achievement sound | needs-original-sound |
| `future-audio/beam.ogg` | beam sound | needs-original-sound |
| `future-audio/bow.ogg` | bow sound | needs-original-sound |
| `future-audio/staff.ogg` | staff sound | needs-original-sound |
| `future-audio/summon.ogg` | summon sound | needs-original-sound |
| `future-audio/melee.ogg` | melee sound | needs-original-sound |
| `future-audio/crossbow.ogg` | crossbow sound | needs-original-sound |
| `future-audio/orb.ogg` | orb sound | needs-original-sound |
| `future-audio/flask.ogg` | flask sound | needs-original-sound |
| `future-audio/harpoon.ogg` | harpoon sound | needs-original-sound |
| `future-audio/lantern.ogg` | lantern sound | needs-original-sound |