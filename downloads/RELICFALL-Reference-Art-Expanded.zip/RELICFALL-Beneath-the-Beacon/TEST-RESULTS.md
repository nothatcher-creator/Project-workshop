# RELICFALL v2 — Validation Results

## Passed automated checks

- `node --check prototype/game.js`: syntax valid.
- `node prototype/runtime-smoke-test.cjs`: pass.
- Catalog count validations: 9 floor biomes, 9 boss specifications, 27 floor-specific enemies, 30 weapon variants from 10 functional attack classes, 200 named item effect definitions, 30 tracked achievement definitions.
- Runtime check: start run; auto-fire enabled by default on simulated touch device; dodge cooldown; item pickup modifies actual stats; weapon switch; advance across floor boundary; open/exit secret combat vault.
- Workshop additive import format checked: project nodes and asset pointers resolve; documents and reference art included.

## Visual/content status

- Derived, reworked **actual user reference images** included for the keeper, lighthouse cutaway, gearworks, undersea descent and leviathan boss.
- Nine depth-specific atmosphere layers are made directly from supplied references.
- Geometric enemy silhouettes and floor overlay lines still exist as playable **interim procedural rendering**; 27 finished enemy character images and 8 additional finished bosses are not falsely claimed as completed art.
- 200 item icons are not individually illustrated yet. `data/reference-art-asset-manifest.json` enumerates required visuals and sounds for further production.
- Full browser navigation was not testable in the current execution environment because the managed Chromium environment blocked navigation; do a desktop/mobile real browser playtest before calling this production-ready.
- Community showcase is curated/read-only with import/exportable local share codes, **not** a live player-submission backend. Community moderation/hosting needs a separate service.
- Project0 native avatar API integration and publishing have not been verified.
