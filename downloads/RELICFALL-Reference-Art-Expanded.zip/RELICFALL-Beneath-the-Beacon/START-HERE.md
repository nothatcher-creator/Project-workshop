# RELICFALL: Beneath the Beacon — Reference-Art Production Bible

**Visual rule:** No empty sprite-sheet templates or generic moodboards. The embedded lighthouse keeper, gearworks, lighthouse descent and corrupted leviathan images are actual visual source material. Derive finished game assets from those references. Technical sprite dimensions can still be documented as requirements, never substituted for artwork.

**Scope:** Nine descending floors, 27 floor-bound enemies (three per floor), nine actual boss encounters, 30 hand-authored agent-forged weapons across ten functional weapon archetypes, 200 items with stat effects, 30 achievements, main menu, tutorial, local share-code showcase, shop, chests and secret vaults.

**Important production distinction:** The runtime has working simple geometric foes, projectiles and reference-derived environmental layers. Full bespoke top-down art for all 27 enemies/nine bosses is still on the asset manifest and should be generated using the reference images.

## Start now
1. Open `prototype/index.html` from a local web server because `catalog.json` loads through fetch. Run `python -m http.server 8000` inside `prototype/` and open `http://localhost:8000`.
2. Preview the player, rooms and bosses. Settings turn automatic mobile firing on/off.
3. Reference images and floor layers are under `prototype/assets/`; the five style references are duplicated under `references/`.
4. `data/full-catalog.json` defines all actual gameplay items/enemies/weapons/bosses/achievements. `data/reference-art-asset-manifest.json` lists every delivered vs still-required visual/audio asset. 
5. `RELICFALL-Add-Project.json` is the editable, additive Project Workshop import. It **preserves** existing projects when imported.
6. The community showcase is read-only from a bundled curated list plus local share codes. Public write access requires moderation/backend.

## Controls
Desktop: WASD/arrows, mouse/Space to fire when auto-fire off, Shift dodge, E interact, P/Esc settings. Mobile: virtual joystick, DODGE button, automatic nearest-target fire by default, optional FIRE button when disabled.

## Gameplay
Each floor has 4 chambers; chamber four contains that floor's named boss. Room completion opens a hatch at the top; selected rooms have shop stalls and chests, and a secret chamber can be found through a cracked west wall. Enter secret rooms, fight guardians, open the treasure and return through its hatch. Each character dies permanently per run; achievement progress, armory unlocks and local custom designs persist in the browser.

## Reference art
- `references/keeper-reference.webp` — keeper with red scarf, suspenders, torn nautical outfit (cut from your reference image)
- `references/leviathan-boss.webp` — corrupted tentacled lighthouse boss (cropped from your reference)
- `references/gearworks-reference.webp` — machinery, brass chains, ceiling architecture
- `references/descent-reference.webp` — multi-depth lighthouse descent
- `references/abyss-reference.webp` — underwater / infernal transition

**Do not misrepresent reference photographs or concept images as completed top-down sprite animation frames.**
