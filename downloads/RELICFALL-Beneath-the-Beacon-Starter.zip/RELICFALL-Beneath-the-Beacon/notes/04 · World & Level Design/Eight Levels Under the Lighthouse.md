# Eight Descending Strata

The geography should gradually deform, never cut straight from cozy stone cellar to generic flames. Familiar lighthouse props recur in corrupted forms.

| Depth | Level theme | Normal anchor | Hellish escalation | Main hazard | New enemy | Guardian |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | **Lighthouse Top** | keeper's desk, lamp, rain | unsettling vibration | none | none | none |
| 1 | **The Ordinary Cellar** | fuel drums, service stairs | a second door that isn't on plans | falling shelves | Rats | Storage Warden (optional) |
| 2 | **Flooded Maintenance** | pumps, pipes, valves | brackish water flows upward | conductive puddles | Drowned Wisp | The Pumpman |
| 3 | **Salt Chapel** | old coastguard chapel | chapel walls whisper names | salt spikes | Saltbound | Choir of Rust |
| 4 | **Fungus Quarters** | crew bunks, linen closet | beds root into flesh | spore bursts | Husk Bloom | Mother Spore |
| 5 | **Brass Furnace** | generator machinery | cogs grind bones | timed heat vents | Furnace Imp | Furnace Saint |
| 6 | **Drowned Catacombs** | shipwreck stores | drowned corpses in suspended water | tide surges | Anchor Revenant | Drowned Captain |
| 7 | **Abyssal Lens** | beacon lens motifs | light bends and lies | false safe zones | Lens Wraith | False Keeper |
| 8 | **The Buried Sun** | lighthouse beam | fully infernal impossible space | arena light inversion | Sunless Guardian | The Lantern Below |

## Room structure
- 2–4 random rooms per floor; final room of a major floor can be a boss arena.
- Each room has `seed`, `depth`, `biome`, `shape`, `spawnTable`, `hazards`, `reward`, `exits`.
- Encounter budget increases by depth: `budget = 3 + depth*2 + floor(roomIndex/2)` with elite cap.
- A `safeEntryRadius` keeps spawn positions ≥ 135px from keeper.
- Multiple room silhouettes: square, T, cross, broken ring, pump corridor, flooded hall.

## Escalation language
Depth 1: soft rain and low amber light; depth 3: whispers, shadows and wrong windows; depth 5: rust and bone; depth 8: distorted lens flare / impossible sun. Accessibility: motion and flashing must be adjustable.
