# Random Room Generation Contract

## Generation algorithm
1. Derive deterministic room seed from run seed + depth + room index.
2. Choose one allowed room silhouette and place 2–6 large collision obstacles avoiding entrance, hatch and a 135px spawn-safe region.
3. Choose props from `normal`, `twisted`, `infernal` palette depending on `depth`.
4. Select weighted hazards by depth; no unavoidable instant damage.
5. Spend encounter budget on enemy pack templates rather than spawning enemies uniformly everywhere.
6. Assign exit hatch; lock until combat ends (or after a specified survival timer).
7. Add reward: embers / chest / shrine / story note / secret.
8. Validate path exists between entrance and exit using flood fill; regenerate failed layouts.

## Room modifiers (chance increases with depth)
- **Flicker:** periodic lantern darkness, telegraphed.
- **Flood:** shallow water slows movement outside raised tiles.
- **Echo:** enemies briefly respawn as weaker spectral copies.
- **Wrong Door:** an extra locked door holds a rare treasure or mimic.
- **Oblique Light:** floor warning lines appear as lens refractions.
- **Reverse Tide:** slow moving hazard sweeps wall to wall.

## Telegraphed hazards
- Water arc: striped warning 0.6s before discharge.
- Vent: glowing floor grate, 0.7s before heat jet.
- Bell: expanding circle 0.65s before impact.
- Avoid random invisible traps; readability first.

## Difficulty & QA
- Seed display in pause for bug reporting.
- Ensure enemies never spawn on top of player / inside solid obstacle.
- Ensure hatches are reachable after every chamber, including touch-only players.
- Keep the first room of Depth 1 easy with optional tutorial labels; deeper layouts gradually gain twists.
