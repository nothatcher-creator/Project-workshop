# Enemies and Bosses

## Standard enemy templates
| Enemy | Depth debut | HP | Behaviour |
| --- | ---: | ---: | --- |
| Bilge Rat | 1 | 20 | rushes keeper, melee contact |
| Drowned Wisp | 2 | 28 | circles keeper, launches visible slow bolts |
| Saltbound | 3 | 46 | windup → dash, leaves salt trail |
| Husk Bloom | 4 | 40 | periodically releases spore warning circles |
| Furnace Imp | 5 | 55 | telegraphed ranged fan attack |
| Anchor Revenant | 6 | 95 | slow advance, frontal cone swing |
| Lens Wraith | 7 | 52 | phantom duplicates, true body carries light |
| Sunless Guardian | 8 | 180 | beam arcs, exposes safe lanes |

## Boss pattern principles
Each major boss has 3–4 attacks, strong telegraphs, cooldown windows, and a recognizable silhouette at low resolution. No 1-frame-hit surprise. Add additional mechanics by floor rather than pure HP inflation.

## Example: The Pumpman (Depth 2)
- Phase 1: magnetic chain pulls water puddles toward center; safe edges visible.
- Phase 2: crossing valves electrify with 0.7s striped warning.
- Vulnerability opens after a 1.2s overpressure animation; player can dodge through an incoming chain, not through walls.

## Example: The False Keeper (Depth 7)
- Uses a mirrored static keeper portrait. Their weapon is the corrupt silhouette of the starter weapon.
- Throws delayed shadow lances that fake your auto-target lock. Telegraph clearly displays true lane vs decoy.

## First playable scope
Bilge Rat, Wisp, Saltbound, Furnace Imp plus one guardian with windup and area attack. Other boss designs are roadmap content, not asserted complete.
