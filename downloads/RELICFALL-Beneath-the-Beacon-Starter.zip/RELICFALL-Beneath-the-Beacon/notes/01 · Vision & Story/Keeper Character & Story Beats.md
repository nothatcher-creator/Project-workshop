# The Lighthouse Keeper

## Design
- **Identity:** The Last Keeper (renameable later), isolated but practical, long dark coat, oilskin hood, heavy sea boots, brass keys, extinguished lantern.
- **Static avatar:** baseline idle still works as the whole game avatar. Move by sliding a single frame; face through mirror/rotation or directional sprites only if provided.
- **Silhouette:** small hood, rounded lantern glow, angular coat taper, white/amber light that always contrasts with floor.
- **Emotions without animating:** a halo dimming on hurt; lantern brightening on heal; trail/dust on dodge; coat colour changes when cursed.

## Story through environment
- The stairwell seems to lead under the building; measurements stop agreeing.
- The keeper finds maintenance notes in their own handwriting dated centuries earlier.
- At deeper levels the lighthouse beam shines *up* through cracks from below.
- The final chamber reveals a sun imprisoned as the lamp's original fuel.

## Narrative pickups (example)
1. `Pump Maintenance — Salt Pump 2`: ordinary work order.
2. `Waterline Log`: water has risen against gravity.
3. `Keeper Register`: the keeper signed it every year for 400 years.
4. `The Mirror Crew`: reports of workers with lamps instead of faces.
5. `Final order`: extinguish the false sun, or feed it your own light.

## Endings (later)
- **Keep the Light:** become new immortal keeper.
- **Break the Lens:** release the light at a terrible cost.
- **Walk Away:** only possible after discovering all sealed notes.
