# Game Design Bible

## High concept
*Relicfall: Beneath the Beacon* combines **Brotato's immediate combat**, **Hades-style meaningful upgrades**, and escalating psychological horror. You are the keeper of the last functioning lighthouse. Its beam once sealed something underneath the coast.

## Player fantasy
A solitary, ordinary lighthouse keeper survives hell not with heroic animations but through movement, resolve, an oil lantern and a fantastical weapon forged by the building agent.

## Player-facing loop
**5 seconds:** position, target, fire, read enemy telegraphs, dodge.
**45 seconds:** clear an uncanny chamber, collect embers and an upgrade.
**3 minutes:** descend a floor, see recognizable fixtures degrade, beat an elite.
**15–25 minutes:** pass eight increasingly twisted strata and confront the buried light source. For prototype a 6–10 minute partial route is appropriate.

## Run structure
- One lighthouse surface intro; descend into floors 1–8.
- Each floor consists of 2–4 generated chambers, with an elite/boss chamber at selected intervals.
- Rooms are hand-designed modular layouts combined using seeded RNG, with enemy packs, props, encounter modifiers and rewards rolled independently.
- Room completion unlocks a downward hatch or door; camera cuts to the next room rather than scrolling the whole world.
- Permanent unlocks are optional future work; death restarts from above the cellar.

## Boundaries
- No pay-to-win, cryptocurrency, real-world loot boxes, or avatar animation dependency.
- Must work on Android touch and desktop keyboard/mouse.
- Keep fair hit indicators, hit pause, readable 2D contrast and stable 60 fps target (30 fps minimum on weak phones).

## Prototype-first scope
1 character, 1 agent-created starter weapon, 4 enemies, 8 themes, seeded rooms, auto-fire setting, dodge, one boss, XP/upgrades, death/retry.
