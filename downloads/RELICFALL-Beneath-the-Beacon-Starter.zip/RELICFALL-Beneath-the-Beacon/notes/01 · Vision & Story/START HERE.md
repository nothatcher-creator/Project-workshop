# RELICFALL — Beneath the Beacon

**Genre:** top-down 2D action roguelike | **Lead:** The Last Lighthouse Keeper | **Target:** Project0 mobile & desktop | **Status:** Design + standalone prototype.

## Premise
A remote lighthouse goes dark during a storm. The keeper climbs down to the perfectly ordinary maintenance cellar to restore power. Every floor below becomes less possible: saltwater seeps upward, rooms shift, history rots, and hell opens under the light. The only way back is to drag the lighthouse's stolen flame to the heart of the abyss.

## Player character
The **Lighthouse Keeper**: weatherworn coat, yellow oilskin hood, brass keys, lantern; usually a static 2D avatar/sprite, even while moving. Attacks, dodges, weapons, lantern light and enemies animate independently. An existing custom avatar may be used if host APIs support it; do not assume automatic access to Project0 identity or avatar model.

## Three game pillars
1. **A lighthouse becoming hell:** every descent retains normal-world features twisted progressively into infernal nightmares.
2. **The agent forges your first weapon:** the builder designs an original signature weapon with working attacks, art, JSON stats, animation sheet and lore (not just a description).
3. **Good on a phone:** automatic fire enabled by default on mobile, reversible in Settings, plus an intentional dodge button and clear telegraphs.

## Start here in Workshop
1. Read **Combat & Mobile Settings** and **Dodge & Invulnerability**.
2. Read **Agent Weapon Forge Brief** and give the agent the build instructions from **Agent Master Prompt**.
3. Check **Sprite Atlas Standard** and open the attached layout PNGs in Assets. Every animation must follow this layout and JSON metadata.
4. Open the stand-alone `prototype/index.html` to test movement, auto-fire, dodge and room descent.
5. Add artwork to Assets and refine mechanic notes. This Workshop import is editable; it does not publish a Project0 experience.

## Release guardrails
- Confirm current Project0 game docs and integration restrictions before implementation in an actual lot.
- Keep user API keys and account credentials out of builds and notes.
- Do not publish a public lot without the owner's explicit approval.
- Multiplayer and real-time AI artwork generation are **not** assumed supported or in scope.
