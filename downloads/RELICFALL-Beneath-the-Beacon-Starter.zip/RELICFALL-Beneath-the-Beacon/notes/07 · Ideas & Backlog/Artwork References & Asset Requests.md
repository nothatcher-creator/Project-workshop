# Reference & Asset Requests

## Avatar request
Produce a 64x64 transparent 2D Lighthouse Keeper idle sprite, front view south; weatherworn yellow oilskin coat, lantern in left hand, sea boots, brass keys. Keep strong silhouette, dark fantasy pixel-art style, readable at 32px. No platform franchise imagery.

## Weapon agent request
See **Agent Weapon Forge Brief** and **Agent Asset Request Template**. The starter weapon must be invented by the agent, not designed from a downloaded existing franchise texture.

## Environment requests
- Level 1 dry timber floor / intact brass valve / normal fuel barrel.
- Level 2 flooded pipe / broken pump / foam and bubbles.
- Level 3 salt-glass chapel window / still prayer bench.
- Level 4 rooted bunk bed / fungal spore pods.
- Level 5 infernal furnace vent / brass gear.
- Level 6 drowned bones / drifting seaweed.
- Level 7 bending Fresnel glass / double shadows.
- Level 8 inverted beacon and black sun.

## File rules
PNG RGBA with transparent background for characters/VFX; nearest-neighbour for pixel art. Follow atlas contract. Keep layers separate and embed metadata in JSON. Only upload assets you own or have permission to use.
