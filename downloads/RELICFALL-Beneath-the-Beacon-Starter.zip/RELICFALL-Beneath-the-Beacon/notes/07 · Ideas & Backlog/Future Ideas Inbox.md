# Ideas Inbox

- A logbook that tracks which of the keeper's own death notes have been found.
- A bell chime when the next layer's boss is near (accessible toggle).
- Environmental descent music that gradually loses rhythm and becomes a heartbeat.
- A false lighthouse beam that appears to illuminate the wrong direction.
- Weapon mutations tied to current floor hazards (salt conducts, lens reflects, oil ignites).
- Optional lantern fuel that can temporarily reveal hidden doors.
- Elite rooms forcing deliberate dodge timing rather than pure damage stacking.
- A ghost silhouette of previous run's keeper at the deepest death location.
- Rare room: ordinary supply closet at Depth 7, frightening specifically because nothing is wrong.
- Branching choice: keep the light burning and remain trapped, or extinguish it to free the dead.
