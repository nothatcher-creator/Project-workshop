# Project0 Integration — verification required

The design package and playable prototype are general browser artifacts, NOT automatically a published Project0 experience. Before binding to a lot, read these living documents directly:
- `https://project0.city/skill.md`
- `https://project0.city/guides/games.md`
- `https://project0.city/guides/assets.md`

## Unknowns to verify
- Accepted game source file format, code size, permitted dependencies / external URLs.
- Whether game runs in iframe, isolated JS, canvas, sandbox with restricted input/audio.
- Lifecycle hooks, save-state/score APIs, click/touch behaviour on mobile.
- Ability to access actual user avatar assets from inside a game.
- Entry, exit, and multiplayer assumptions; moderation/licensing requirements.
- Lot ownership and publication rights.

## Safe fallback
Host the game as self-contained Canvas app first. Keep a static portrait fallback for character. Do not code around unverified internal endpoints, scrape live player/account data, or embed API keys. Do not overwrite an existing public lot without explicit approval.
