# Roadmap

## Phase 0 — Design (this import)
- [x] Narrative + 8 depth themes
- [x] Mobile auto-fire ON/OFF spec
- [x] Dodge specs + input priorities
- [x] Agent weapon forge process and JSON schema
- [x] Universal sprite atlas layout + blank PNG templates
- [ ] User review and balancing

## Phase 1 — Prototype
- [x] First AI-created starter weapon: The Wickpiercer, original sprite atlases + working prototype attacks (can be refined/replaced by the Project0 building agent)
- [ ] Static keeper avatar + true transparent artwork
- [ ] Keyboard movement + multitouch joystick
- [ ] Auto-fire ON by default on mobile + toggle persisted
- [ ] Manual FIRE when disabled
- [ ] Shift/touch dodge with true i-frames and wall collision
- [ ] Procedural chamber transitions and increasing depth palette
- [ ] Death/restart, room clear, simple upgrades

## Phase 2 — First vertical slice
- [ ] 4 enemy behaviours + one guardian
- [ ] Three choice XP upgrades
- [ ] Hazards with clearly visible warning time
- [ ] 8 room-theme escalation presets
- [ ] Working pause/settings + first-run tutorial

## Phase 3 — Art & atmosphere
- [ ] Replace simple geometry with completed atlas animation assets
- [ ] Layered sound (storm → water → metal → infernal pulses)
- [ ] Story notes + background easter eggs
- [ ] Sprite renderer / animation events / atlas validation

## Phase 4 — Platform
- [ ] Confirm current Project0 compatibility
- [ ] Optimize memory and input for embedded runtime
- [ ] Verify user avatar access and graceful fallback
- [ ] Owner approval before publishing to a public lot

## Scope intentionally postponed
Network leaderboards, cooperative play, persistent cloud saves, direct live-agent weapon creation during each run.
