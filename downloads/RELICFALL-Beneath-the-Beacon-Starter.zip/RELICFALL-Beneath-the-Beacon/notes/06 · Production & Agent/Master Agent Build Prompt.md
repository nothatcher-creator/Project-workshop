# Copy-Paste Project0 Agent Master Brief

You are the lead game designer, artist, programmer, QA and technical integrator for **RELICFALL: Beneath the Beacon**.

## Required first actions
1. Read the attached docs and their canonical names: Game Design Bible; Mobile Settings & Auto Fire; Dodge & Invulnerability; Eight Levels Under the Lighthouse; Agent Weapon Forge Brief; Sprite Atlas Standard; Weapon Data Schema.
2. Read and confirm current authoritative Project0 documentation: `https://project0.city/skill.md`, `https://project0.city/guides/games.md`, `https://project0.city/guides/assets.md`. If they cannot be fetched, log the unknowns instead of guessing or publishing.
3. Independently **create a starter weapon**, inspired by lighthouse parts. Design original sprite / SVG art and projectile VFX, JSON data, functional hit collision, special effect, and animations. Player should never need to create the starting weapon for you.
4. Build a **top-down** mobile-first roguelike. Main character is a **Lighthouse Keeper** with static fallback sprite: moving the still image around counts as valid animation-free avatar movement. All weapon FX, dodges, enemies and environment animate independently.

## Gameplay contract
- On mobile, Auto Fire is **ON on first load**. Settings must permit **ON/OFF** and save choice between visits.
- When OFF, an accessible visible FIRE button must work; when ON, attack nearest eligible visible enemy automatically without penetrating walls.
- Dodge via large phone button and Shift on desktop: 120px / 0.22s, 0.16s i-frames, 1.5s cooldown. Collision against solids required; good afterimage FX.
- Multiple levels descending **beneath the lighthouse**: start with ordinary cellar and gradually become hellish. Distinct depth-specific colours, props, enemies and hazards. Procedurally arrange each room from a seeded RNG, validate reachable exit.
- Add XP, leveling choices, enemy telegraphs, death/restart, room transitions, readable touch HUD.
- Use sprite atlases: 8 columns × 8 direction rows, 64px cells for player/enemies/weapons, 128px for bosses; 8×1 for directionless FX. Obey row ordering `N NE E SE S SW W NW`. Each action has separate file + manifest. MVP can use static keeper S-facing frame 0; do not fake a completed sprite atlas.

## Agent-made weapon section
Always generate actual artwork and structured weapon data, then document tests and balancing. Required `weapons/starter-weapon.json`, `weapons/weapon.schema.json`, sprite or SVG, projectile hit effect and implemented firing logic. Future weapon families from design docs are references, not mandatory for v1.

## Order of implementation
A. Weapon concept, art & working data/attack.
B. Start room, player movement, settings, auto/manual fire, dodge and one enemy.
C. Seeded rooms, depth escalation, telegraphed threats and room hatch transitions.
D. XP/upgrades, enemy variety, one boss and UI polish.
E. Test on mobile & desktop, log verified vs unverified, produce platform integration package.

## Important safety and launch limits
Do not assume Project0 exposes custom avatar models or permits arbitrary remote assets. Do not paste keys into JS. Do not claim a multiplayer/saving feature is tested until verified. Do not publish the live lot or irreversibly replace existing work without explicit owner approval. Prioritize a functional playable prototype over oversized promises.

## Deliverables
1. Full source; 2. artwork files (not merely prompts); 3. data schema/manifest; 4. a running prototype; 5. test log with device context; 6. precise Project0 integration steps and limitations; 7. list of incomplete features.
