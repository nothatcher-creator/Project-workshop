# Mobile Settings — auto-fire is ON by default

## Critical requirement
Mobile launches with **Auto Fire = ON** on a fresh install. Settings has a plainly labeled **Auto Fire ON/OFF toggle**, available from pause and main menu, and remembers the choice across runs (`localStorage` or supported host save API).

## When Auto Fire is ON
- Aim at closest eligible enemy **in range and visible**; prefer the enemy closest to the facing/aim direction when manual aim is active.
- Fire on weapon cooldown, even while moving or dodging (subject to weapon's explicit cancel rules).
- Respect collision/line of sight. Never auto-target through a sealed wall.
- If no valid enemy exists, don't waste shots (unless weapon is explicitly an always-firing pattern).
- Visual targeting ring allows the player to know which enemy will be hit.

## When Auto Fire is OFF
- Show large right-side **FIRE** touch button (hold to repeat according to cooldown).
- On desktop: mouse hold / Space to shoot, with optional auto-fire toggle.
- Aiming: prefer last touch direction or nearest enemy, then manual right-stick drag in later versions.
- Switching back ON immediately resumes targeting.

## Controls
| Input | Desktop | Phone/tablet |
| --- | --- | --- |
| Move | WASD / arrows | Large floating joystick, bottom-left |
| Fire | Mouse hold / Space (when manual) | Fire button (when manual) |
| Dodge | Shift / right click | Large DODGE button, bottom-right |
| Pause / Settings | P or gear | Gear button, top-right |
| Upgrade choice | Keys 1-3 or click | Tap large cards |
| Interact | E | Interact button if needed |

## Settings scope
- Auto Fire (on by default for mobile; configurable desktop)
- Aim Assist (on/off; independent of Auto Fire)
- Screen Shake (on/off)
- Reduced Motion (on/off)
- Damage Numbers (on/off)
- Sound/Music volume (future)
- Contrast Mode (future)

## UX acceptance tests
- Fresh Android starts firing automatically when monsters appear.
- OFF genuinely stops fire until manual input; FIRE button becomes visible.
- Settings persist after reload; toggling does not reset the run.
- Touch joystick and dodge work concurrently (multi-touch).
- Buttons are at least 48 CSS px; respect safe-area insets and screen orientation changes.
- No background firing while paused, selecting a level-up or game over.
