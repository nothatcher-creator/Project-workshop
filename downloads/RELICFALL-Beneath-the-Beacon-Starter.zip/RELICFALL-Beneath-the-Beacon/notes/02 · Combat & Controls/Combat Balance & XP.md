# Combat Balance and Levelling

## Baseline keeper
- HP: 100; walk speed: 190 px/s; hurt i-frame: 0.45 s.
- Dodge: 120 px / 0.22 sec, 0.16-s i-frame, 1.5-s cooldown.
- Healing drops restore 12–22 HP; no automatic regeneration except rare shrine.
- Auto Fire: ON for Android; per-device preference persisted.

## XP
- Required XP: `20 + 10 * (level-1)` for levels 1–5, then increase modestly.
- Three cards at each level-up, reroll only when an upgrade provides it.
- Pauses action while cards are displayed.

## Suggested upgrade cards
| Perk | Effect |
| --- | --- |
| Steady Hands | -9% weapon cooldown (floor 0.3s) |
| Wicked Wick | +15% weapon damage |
| Polished Lens | +15% reach |
| Sea Boots | +12% move speed |
| Hot Brass | +12% area / splash radius |
| Second Chance | +1 extra dodge charge (rare) |
| Keeper's Breath | +20 max HP and heal 20 |
| Lamp Fuel | Next 6 kills drop extra embers |
| Evasive Memory | -12% dodge cooldown |
| Black Salt | Hit enemies apply 1.5-sec slow |

## Enemy progression guardrail
Scale **one lever at a time** per floor: enemy HP, encounter count, attack frequency, or room hazard density. Do not multiply all four steeply together. A beginner should reach floors 2–3 in their first few tries, not die in the first ten seconds.
