# New Agent-Made Weapon — Reusable Request

Copy and customize this into any agent task:

> Invent, draw and integrate ONE new weapon into RELICFALL: Beneath the Beacon. It must visually fit the Lighthouse Keeper and the current depth. Deliver: (a) a filled stats JSON validated against `weapon.schema.json`; (b) transparent weapon idle/swing sprite sheet following atlas standard; (c) projectile / impact / special effects sheets as needed; (d) one 64px inventory icon; (e) engine implementation with collisions and no wall penetration; (f) tested mobile auto/manual fire; (g) balance explanation and an exact list of generated files. Prefer original game mechanics, not reused generic swords. Do not overwrite existing working weapons or publish publicly without approval.

## Weapon review worksheet
**Proposed name:**
**Archetype and origin story:**
**Sprite readability at 32px:**
**Damage / cadence / range:**
**Unique ability:**
**Combo upgrades:**
**Tests passed:**
**Files to attach:**
**Status:** Idea / Needs art / Needs testing / Accepted
