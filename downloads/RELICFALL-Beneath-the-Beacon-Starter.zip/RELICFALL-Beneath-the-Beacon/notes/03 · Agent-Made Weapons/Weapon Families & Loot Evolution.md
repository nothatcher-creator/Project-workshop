# Weapon Families and Mutations

## Eight candidate families for later agent creations
1. **Wickpiercer** — harpoon / flare / delayed ignition.
2. **Glasswake** — rotating Fresnel-lens beam reflecting off polished surfaces.
3. **Saltwake Bell** — area ringing attack; increases damage near cursed water.
4. **Mariner's Hook** — ricocheting thrown chain returns to keeper.
5. **Fogmouth** — short cone of salt spray that reveals invisible threats.
6. **Tideglass Needle** — crystalline beam that splits after each ricochet.
7. **Blackwater Lamp** — orbiting oil-fire familiar and corrosive puddles.
8. **The Last Buoy** — delayed explosive marker detonates after a dodge.

## Loot rules
- Starting weapon is unique (one active slot), forged by agent at build time.
- In-run upgrades modify damage, attack rate, projectile count, status effect, reach or special shape.
- Two rare upgrades may change the special function: `Chain Flare` or `Refraction`.
- Post-boss loot can yield a second agent-authored weapon, but enforce weapon asset + JSON + tested mechanics.
- Weapon descriptions and rarity colours should never replace clear numeric differences.

## Naming guidance
Avoid copying recognizable weapon names, images or sound from existing games. Names should suggest brass, sea, light, salt and horror; no franchise references.
