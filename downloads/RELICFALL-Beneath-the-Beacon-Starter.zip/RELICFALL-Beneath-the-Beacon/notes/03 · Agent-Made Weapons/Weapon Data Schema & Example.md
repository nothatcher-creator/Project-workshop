# Weapon JSON Contract

**Source of truth:** `weapons/starter-weapon.json` and `weapons/weapon.schema.json` in export package. Stats are editable; game loads a validated data object rather than relying on prose.

## Must-have fields
- `id`, `name`, `lore`, `archetype`, `element`, `rarity`, `damage`, `cooldownSeconds`, `rangePx`, `projectileSpeedPxPerSec`, `collisionRadiusPx`, `aimMode`, `shotCount`, `special`, `asset`, `animation`, `audio`.
- Optional `penetration`, `ricochet`, `heat`, `spreadDegrees`, `projectileLifeSeconds`.
- Agent can add fields but must keep old save data valid and update validators.

## Fire acceptance
1. Mobile with auto-fire ON targets nearest **visible** valid enemy in range and fires automatically.
2. OFF requires explicit input (manual FIRE button).
3. Agent weapon appears clearly next to stationary-pose keeper.
4. Hits decrease HP exactly once each and cannot pass through solid collision blockers.
5. Special triggers only when stated condition occurs.
6. Distinct visible animation states: idle, windup, fire, projectile, impact, special.
7. HUD displays actual runtime damage/cooldown, not stale hard-coded labels.

## Security / practical limits
Build-time agent decides and draws; do not assume Project0 supports live AI generation, network image services, external accounts, or API keys within game runtime. Runtime loot can use seeded procedural variations from approved modular components.
