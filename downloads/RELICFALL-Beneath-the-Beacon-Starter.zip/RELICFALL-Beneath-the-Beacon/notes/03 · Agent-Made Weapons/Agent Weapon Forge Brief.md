# Agent Weapon Forge — mandatory first step

The **building agent** must create an original starter weapon that belongs to the Lighthouse Keeper. Do not use a generic stock sword. The weapon must exist as a real asset with collision mechanics, a data file and an animation atlas or documented procedural animations.

## Creative source material
Design around nautical relics, brass lighthouse machinery, lenses, oil, shipwreck tools, salt, signal lamps, bells, anchor hooks, or condemned sea life. The deeper world contains infernal variants; the starting weapon should still resemble a **believable keeper tool made supernatural**.

## Required output from the agent
1. Original weapon name, silhouette, clear lore in ≤ 3 sentences.
2. Choose one **archetype** (lantern-focus, flare-gun, harpoon, chain-hook, signal-bell, salt-sprayer, arc-lens, crank-blade) and one attack behaviour (bolt, arc, beam, melee sweep, thrown return, orbiting, burst).
3. One **distinct special mechanic** beyond +damage: ricochet off wet walls, flare marks, oil pool ignition, timed recall, charged bell shockwave, heat buildup, target tether, etc.
4. Fair stats compatible with the balance table. No instant-kill or firing through walls.
5. Draw/source **actual weapon art** (PNG, SVG or code-rendered vector), a thumbnail, 8-frame 64px layout as appropriate, muzzle flash/impact VFX, and data JSON. If no raster generator exists, use handcrafted SVG and save it.
6. Implement actual target selection, projectile / hit detection, firing cadence and FX in game.
7. Run mobile tests with Auto Fire ON and OFF and report exact results.

## Example *only* — agent should improve or replace
**The Wickpiercer** (first agent-made version): a brass harpoon launcher built from the lamp's pressure regulator. Fires amber lance bolts. Every fifth enemy hit leaves a suspended flare that detonates after 0.8 s. Baseline: 13 damage, 0.72-s cooldown, 245px range, 440px/s projectile, 8px collision radius. Actual 64px weapon atlases, icon and directionless effect sheets are bundled in the asset library.

## Creative pass/fail rubric (out of 10 each)
- Fits keeper/lighthouse fiction
- Distinct silhouette at 32px
- Readable on a dark background
- A special ability with interesting player decisions
- Balanced sustained DPS / attack windows
- Usable without avatar animation
- Clear mobile target effects
- All visual files actually exist
- JSON fields match real gameplay
- Audio + accessibility alternatives

**Accept only ≥ 80/100 with no zero in gameplay functionality or asset existence.**
