# Art Direction

## Visual evolution
**Above ground / depth 1:** lantern amber `#F1C677`, desaturated timber, soot slate `#28313A`, wet greys.
**Depth 2–3:** salt white, algae turquoise `#538C8D`, cold mist.
**Depth 4–5:** red fungal pulp `#9A424F`, furnace copper `#C7602E`, deep shadows.
**Depth 6–7:** drowned violet `#665A90`, cosmic blue `#5261B6`, false gold.
**Depth 8:** charcoal void `#09070C`, blood orange `#E5573F`, reversed white-light beam.

## Lighting
Keep character silhouette bright enough for phone. The lantern creates a dim pool of light; it must not obscure hazards under accessibility contrast mode. Avoid critical information conveyed only by colour. Avoid full-screen strobing and provide reduced-motion toggle.

## UI
Upper left: HP, depth, room, weapon icon. Upper right: settings gear. Lower left: floating joystick. Lower right: dodge cooldown/button; manual fire button appears when Auto Fire is off. Level-up overlay uses 3 large cards, fits portrait and landscape.

## Fidelity and performance
Actual sprites might be produced by an agent later. The standalone prototype intentionally uses clean Canvas primitive shapes and light effects as placeholders. Do not mistake the guide PNGs for finished textured art.
