# Sprite Sheet Layout — Universal Contract

**Assets are sprite sheets, not prose placeholders.** Templates are included in the Asset Library: `player-action-template.png`, `weapon-action-template.png`, `enemy-action-template.png`, `boss-action-template.png`, `vfx-action-template.png`, and the annotated `sprite-atlas-layout.png`. Each includes alignment/safe-zone guides.

## Player and directional enemies
- Separate PNG per **animation action**, e.g. `keeper_idle.png`, `keeper_dodge.png`, `rat_hurt.png`.
- Each action page has **8 columns × 8 rows** with transparent background.
- **64×64 pixel cells** → sheet size **512×512** for player, smaller enemies and handheld weapons.
- Columns = frame index **0…7** (left to right). Rows = direction index **0…7** from top to bottom: `N, NE, E, SE, S, SW, W, NW`.
- Frames with no sprite for short actions may remain transparent; `frameCount` in manifest tells runtime how many valid frames to animate. Do NOT sample blank frames.
- Character feet / collision anchor: cell center `x=32,y=52`; weapons use origin `x=32,y=32`.
- No margin or spacing between atlas cells (runtime uses exact `x = frame*64; y = direction*64`).

## Bosses & large effects
- Boss actions: 8×8 grid, **128px cells** → **1024×1024** page.
- Directionless effects/props: **8 columns × 1 row**, 128px cells, **1024×128** PNG. Runtime uses row zero only.
- UI icons: **32×32** one image or atlas icons grid; pixel-perfect nearest-neighbour when upscaled.

## Suggested animation library
| Actor or system | Required actions | Frame counts (initial) |
| --- | --- | --- |
| Keeper | idle, walk, dodge, hurt, death, interact | 4, 6, 6, 3, 8, 6 |
| Weapon | idle, windup, fire, reload, special | 4, 3, 4, 6, 8 |
| Projectiles | fly, impact | 4, 6 |
| Bilge Rat | idle, walk, attack, hurt, death | 4, 6, 5, 3, 6 |
| Drowned Wisp | float, cast, hurt, death | 6, 6, 3, 7 |
| Saltbound | walk, telegraph, dash, hurt, death | 6, 4, 4, 3, 8 |
| Furnace Imp | idle, walk, fire, hurt, death | 4, 6, 5, 3, 7 |
| Each boss | idle, move, telegraph, attack, hurt, phase, death | 4, 6, 6, 8, 3, 8, 8 |
| Environment | lamp-flicker, hatch-open, water-ripple, vent-warning, vent-fire, chest-open | 8, 8, 8, 6, 8, 8 |
| VFX | muzzle, hit, flare-detonation, dodge-trail, heal, curse, levelup | 6, 6, 8, 6, 6, 8, 8 |

## Static avatar exception
Only `keeper_idle` frame `[row=4 (S), col=0]` is mandatory for MVP. In static-avatar mode the animator intentionally uses this one cell for moving, firing and dodging; the weapon, glow and afterimages still animate separately. Remaining sheets are optional extensions that must follow the exact same contract once added.

## Metadata keys
`entity`, `action`, `path`, `cellWidth`, `cellHeight`, `columns`, `rows`, `directions`, `frameCount`, `fps`, `loop`, `pivot`, `renderScale`, `events`.

## Test vectors
- Frame 3 facing west (`directionIndex = 6`) of 64px atlas → source rect `(192,384,64,64)`.
- Frame 7 facing south-east (`index=3`) of 128px boss atlas → source rect `(896,384,128,128)`.
- All atlas images must be RGBA transparent, with no embedded cell guide labels in final game artwork.
