# RELICFALL: Beneath the Beacon — Workshop Import

Open the Project Workshop JSON import (contains editable planning notes + sprite guides). **Workshop v1.1:** use `+ Import project` to ADD this project safely. Older Workshop versions only offer destructive full-backup import: export your existing backup before importing. The standalone prototype is in `prototype/index.html` and the fully editable Markdown notes in `notes/`.

This is a design and starter prototype package, not a publicly published Project0 game. Current live Project0 APIs and avatar embedding are unverified.
