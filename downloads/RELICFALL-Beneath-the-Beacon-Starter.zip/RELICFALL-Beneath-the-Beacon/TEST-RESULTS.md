# RELICFALL — Prototype smoke test report

Tested locally on 2026-10-16 with Chromium (Playwright / screen-size emulation). These are browser smoke tests, **not** physical Galaxy S25 or Project0-host validation.

## Verified in browser emulation
- JavaScript syntax passes `node --check`; game loads without page-level JavaScript exceptions in the tested scenarios.
- Desktop 1200x760: intro opens; settings open; auto-fire can be enabled; game starts with spawned enemies; Shift triggers dodge cooldown.
- Mobile touch emulation 390x844: Auto Fire starts ON by default; room spawns; FIRE button remains hidden while auto-fire is ON; OFF toggle reveals manual FIRE button; DODGE button triggers cooldown; no page-level JavaScript exceptions.
- Multiple palette stages / room sequence designed for eight depths; random room obstacles and encounter packs are implemented.
- Sprite sheet templates meet dimensions; 114 animation contract entries are supplied; first weapon's 5 weapon action sheets, 2 projectile sheets, 1 flare sheet and 64px icon exist.
- Additive import logic was exercised in a JavaScript isolated test: an existing project/doc remained after importing; 19 assets copied; repeating import assigned fresh IDs.

## Not verified / incomplete
- Physical Android multitouch behaviour and thumb reach on a specific device.
- Public Project0 game host integration, lot publication or actual platform avatar access (platform guides could not be fetched here).
- Audio, 8 full bosses, final textured world tiles, full sprite animation renderer, or cross-device cloud sync.
- Long-run memory/performance at depths 1–8 and fair balance for all random room seeds.

## Commands
- `node --check prototype/game.js`
- Run `prototype/index.html` in a normal browser (or serve folder over local HTTP).

This is a real, playable prototype but not a completed commercial-quality game or an uploaded Project0 experience.
